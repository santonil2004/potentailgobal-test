<?php
require_once 'bootstrap.php';

$brands = get_data_array('Brand', null, false);
$segments = get_segment(false);
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Data entry tool</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="css/textext/textext.core.css" type="text/css" />
        <link rel="stylesheet" href="css/textext/textext.plugin.tags.css" type="text/css" />
        <link rel="stylesheet" href="css/textext/textext.plugin.autocomplete.css" type="text/css" />
        <link rel="stylesheet" href="css/textext/textext.plugin.focus.css" type="text/css" />
        <link rel="stylesheet" href="css/textext/textext.plugin.prompt.css" type="text/css" />
        <link rel="stylesheet" href="css/textext/textext.plugin.arrow.css" type="text/css" />
        <link rel='stylesheet' href='css/style.css' type="text/css"/>


        <script src="js/jquery/jquery-1.8.0.min.js" type="text/javascript" charset="utf-8"></script>
        <script src="js/script.js" type="text/javascript" charset="utf-8"></script>
        <script src="js/textext/textext.core.js" type="text/javascript" charset="utf-8"></script>
        <script src="js/textext/textext.plugin.tags.js" type="text/javascript" charset="utf-8"></script>
        <script src="js/textext/textext.plugin.autocomplete.js" type="text/javascript" charset="utf-8"></script>
        <script src="js/textext/textext.plugin.suggestions.js" type="text/javascript" charset="utf-8"></script>
    </head>
    <body>
        <div class="main-wrapper">
            <div class="data-entry-wrapper">
                <?php echo getMessage(); ?>
                <!-- Segment entry-->
                <fieldset>
                    <legend>Segment Entry</legend>
                    <form action="index.php" method="post" class="segment-entry">
                        <p>
                            <label>Segment</label>
                            <input type="text" name="segment" id="text-segment" autocomplete="off" required=""/>
                        </p>
                        <p>
                            <input type="hidden" value="add_segment" name="action"/>
                            <input type="submit" name="segment_entry" value="Add Segment"/>
                        </p>
                    </form>
                </fieldset>


                <!-- Brand entry-->
                <fieldset>
                    <legend>Brand Entry</legend>
                    <form action="index.php" method="post" class="brand-entry">
                        <p>
                            <label>Segment</label>
                            <select name='segment_id' required="" id='segment_id'>
                                <option value=''>-Select Segment-</option>
                                <?php foreach ($segments as $id => $name): ?>
                                    <option value="<?php echo $id; ?>"><?php echo $name; ?></option>
                                <?php endforeach; ?>

                            </select>
                        </p>
                        <p>
                            <label>Brand</label>
                            <input type="text" name="brand" id="text-brand" autocomplete="off" required=""/>
                            <span class='loading-brand'></span>
                        </p>
                        <p>
                            <input type="hidden" value="add_brand" name="action"/>
                            <input type="submit" name="brand_entry" value="Add Brand"/>
                        </p>
                    </form>
                </fieldset>

                <!-- Model entry-->
                <fieldset>
                    <legend>Model Entry</legend>
                    <form action="index.php" method="post" class="model-entry">
                        <p>
                            <label>Segment</label>
                            <select name='segment_id' required="" id='segment_id'>
                                <option value=''>-Select Segment-</option>
                                <?php foreach ($segments as $id => $name): ?>
                                    <option value="<?php echo $id; ?>"><?php echo $name; ?></option>
                                <?php endforeach; ?>
                            </select>

                        </p>
                        <p>
                            <label>Brand</label>
                            <select name="brand_id" required="" id='brand_id'>
                                <option value=''>-Select Brand-</option>
                                <?php foreach ($brands as $id => $name): ?>
                                    <option value='<?php echo $id; ?>'><?php echo $name; ?></option>
                                <?php endforeach; ?>
                            </select>
                            <span class='loading-brand'></span>
                        </p>

                        <p>
                            <label>Model</label>
                            <input type="text" name="model" id="text-model" autocomplete="off" required=""/>
                            <span class='loading-model'></span>
                        </p>
                        <p>
                            <input type="hidden" value="add_model" name="action"/>
                            <input type="submit" name="model_entry" value="Add Model"/>
                        </p>
                    </form>
                </fieldset>
            </div>
        </div>
        <script>
            var segment = <?php echo get_segment(); ?>;
            var brand = <?php echo get_data_array('Brand'); ?>;
            var model = <?php echo get_data_array('Model'); ?>;
        </script>
    </body>
</html>
