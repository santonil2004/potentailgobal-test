-- phpMyAdmin SQL Dump
-- version 4.0.1
-- http://www.phpmyadmin.net
--
-- Host: database
-- Generation Time: Jan 14, 2015 at 10:59 AM
-- Server version: 5.5.39-log
-- PHP Version: 5.4.32-pl0-gentoo

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `potentiate_2`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_category`
--

CREATE TABLE IF NOT EXISTS `admin_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `type` varchar(32) NOT NULL,
  `description` varchar(128) NOT NULL,
  `active_from_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `inactive_from_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_type` (`code`,`type`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=412 ;

--
-- Dumping data for table `admin_category`
--

INSERT INTO `admin_category` (`id`, `code`, `name`, `type`, `description`, `active_from_date`, `inactive_from_date`) VALUES
(1, 'toyota', 'Toyota', 'Brand', 'Toyota', 0, 0),
(11, 'honda', 'Honda', 'Brand', 'Honda', 0, 0),
(101, 'toyota_medium', 'Medium', 'Segment', 'Toyota Medium', 0, 0),
(21, 'toyota_light', 'Light', 'Segment', 'Toyota Light', 0, 0),
(31, 'brand_overall', 'Brand Overall', 'Model', 'Brand Overall', 0, 0),
(41, 'toyota_light_priusc', 'Prius c', 'Model', 'Toyota Light Prius C', 0, 0),
(51, 'toyota_small', 'Small', 'Segment', 'Toyota Small', 0, 0),
(61, 'toyota_small_corolla', 'Corolla', 'Model', 'Toyota Small Corolla', 0, 0),
(71, 'toyota_small_prius', 'Prius', 'Model', 'Toyota Small Prius', 0, 0),
(81, 'toyota_small_rukus', 'Rukus', 'Model', 'Toyota Small Rukus', 0, 0),
(91, 'toyota_small_priusv', 'Prius v', 'Model', 'Toyota Small Prius V', 0, 0),
(111, 'toyota_medium_camry', 'Camry', 'Model', 'Toyota Medium Camry', 0, 0),
(121, 'toyota_medium_camry_hybrid', 'Camry Hybrid', 'Model', 'Toyota Medium Camry Hybrid', 0, 0),
(131, 'toyota_large', 'Large', 'Segment', 'Toyota Large', 0, 0),
(141, 'toyota_large_aurion', 'Aurion', 'Model', 'Toyota Large Aurion', 0, 0),
(151, 'toyota_compact_suv', 'Compact SUV', 'Segment', 'Toyota Compact SUV', 0, 0),
(161, 'toyota_compact_suv_rav4', 'RAV4', 'Model', 'Toyota Compact SUV RAV4', 0, 0),
(171, 'toyota_medium_suv_soft', 'Medium SUV Soft', 'Segment', 'Toyota Medium SUV Soft', 0, 0),
(181, 'toyota_medium_suv_soft_kluger', 'Kluger', 'Model', 'Toyota Medium SUV Soft Kluger', 0, 0),
(191, 'toyoya_medium_suv_rugged', 'Medium SUV Rugged', 'Segment', 'Toyota Medium SUV Rugged', 0, 0),
(201, 'toyota_medium_suv_rugged_fj_crui', 'FJ Cruiser', 'Segment', 'Toyota Medium SUV Rugged FJ Cruiser', 0, 0),
(211, 'toyota_medium_suv_rugged_prado', 'Prado', 'Model', 'Toyota Medium SUV Rugged Prado', 0, 0),
(221, 'toyota_large_suv', 'Large SUV', 'Segment', 'Toyota Large SUV', 0, 0),
(231, 'toyota_large_suv_LandCruiser', 'LandCruiser', 'Model', 'Toyota Large SUV LandCruiser', 0, 0),
(241, 'toyota_workhorse', 'Workhorse', 'Segment', 'Toyota Workhorse', 0, 0),
(251, 'toyota_workhorse_hilux', 'HiLux (4x2/4x4)', 'Model', 'Toyota Workhorse Hilux', 0, 0),
(261, 'toyota_workhorse_landcruise_cab_', 'LandCruiser Cab Chassis', 'Model', 'Toyota Workhorse LandCruiser Cab Chassis', 0, 0),
(271, 'toyota_sports', 'Sports', 'Segment', 'Toyota Sports', 0, 0),
(281, 'toyota_sports_86', '86', 'Model', 'Toyota Sports 86', 0, 0),
(291, 'toyota_people_mover', 'People Mover', 'Segment', 'Toyota People Mover', 0, 0),
(301, 'toyota_tarago', 'Tarago', 'Model', 'Toyota Tarago', 0, 0),
(321, 'pre_launch', 'Pre Launch', 'Library-Category', 'Pre Launch', 0, 0),
(331, 'post_launch', 'Post Launch', 'Library-Category', 'Post Launch', 0, 0),
(341, 'ongoing_performance_and_tracking', 'Ongoing Performance & Tracking', 'Library-Category', 'Ongoing Performance & Tracking', 0, 0),
(351, 'consumer', 'Consumer', 'Library-Category', 'Consumer', 0, 0),
(361, 'advertising', 'Advertising', 'Library-Category', 'Advertising', 0, 0),
(371, 'quaterly_bct', 'Quarterly BCT', 'Source', 'Data source Quarterly BCT', 0, 0),
(381, 'vfacts', 'VFACTS', 'Source', 'Data source VFACTS', 0, 0),
(391, 'arms', 'ARMS', 'Source', 'Data source ARMS', 0, 0),
(401, 'internal', 'Internal', 'Source', 'Data source Internal', 0, 0),
(411, 'toyota_light_yaris', 'Yaris', 'Model', 'Toyota Light Yaris', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `admin_category_parent`
--

CREATE TABLE IF NOT EXISTS `admin_category_parent` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_category_id` int(10) unsigned NOT NULL DEFAULT '0',
  `parent_admin_category_id` int(10) unsigned NOT NULL DEFAULT '0',
  `active_from_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `inactive_from_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `system_category_id` (`admin_category_id`),
  KEY `parent_system_category_id` (`parent_admin_category_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=422 ;

--
-- Dumping data for table `admin_category_parent`
--

INSERT INTO `admin_category_parent` (`id`, `admin_category_id`, `parent_admin_category_id`, `active_from_date`, `inactive_from_date`) VALUES
(1, 21, 1, 0, 0),
(11, 0, 21, 0, 0),
(21, 31, 21, 0, 0),
(31, 0, 21, 0, 0),
(41, 41, 21, 0, 0),
(51, 0, 1, 0, 0),
(61, 51, 1, 0, 0),
(71, 0, 51, 0, 0),
(81, 61, 51, 0, 0),
(91, 71, 51, 0, 0),
(101, 0, 51, 0, 0),
(111, 81, 51, 0, 0),
(121, 91, 51, 0, 0),
(131, 101, 1, 0, 0),
(141, 111, 101, 0, 0),
(151, 121, 101, 0, 0),
(161, 0, 1, 0, 0),
(171, 131, 1, 0, 0),
(181, 0, 1, 0, 0),
(191, 141, 131, 0, 0),
(201, 0, 1, 0, 0),
(211, 151, 1, 0, 0),
(221, 0, 151, 0, 0),
(231, 161, 151, 0, 0),
(241, 171, 1, 0, 0),
(251, 181, 171, 0, 0),
(261, 191, 1, 0, 0),
(281, 201, 191, 0, 0),
(291, 0, 1, 0, 0),
(301, 211, 191, 0, 0),
(311, 0, 1, 0, 0),
(321, 221, 1, 0, 0),
(331, 0, 1, 0, 0),
(341, 231, 221, 0, 0),
(351, 0, 1, 0, 0),
(361, 241, 1, 0, 0),
(371, 251, 241, 0, 0),
(381, 261, 241, 0, 0),
(391, 271, 1, 0, 0),
(401, 281, 271, 0, 0),
(411, 291, 1, 0, 0),
(421, 301, 291, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `admin_category_target`
--

CREATE TABLE IF NOT EXISTS `admin_category_target` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_category_id` int(11) NOT NULL,
  `code` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `type` enum('PERCENTAGE','COUNT') NOT NULL DEFAULT 'COUNT',
  `value` double(10,6) NOT NULL DEFAULT '0.000000',
  `active_from_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `inactive_from_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_category_code_type` (`admin_category_id`,`code`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_role`
--

CREATE TABLE IF NOT EXISTS `admin_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `description` varchar(128) NOT NULL,
  `permissions` text NOT NULL,
  `admin_system_role_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `name` (`name`),
  KEY `parent_system_role_id` (`admin_system_role_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin_role`
--

INSERT INTO `admin_role` (`id`, `code`, `name`, `description`, `permissions`, `admin_system_role_id`) VALUES
(1, 'NATIONAL_MANAGER', 'National Manager', 'This role is for national login', 'can_access_portal=yes,', 0);

-- --------------------------------------------------------

--
-- Table structure for table `admin_session`
--

CREATE TABLE IF NOT EXISTS `admin_session` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(40) NOT NULL,
  `data` text NOT NULL,
  `expiry_date` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_id` (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='stores session objects in json format' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_site`
--

CREATE TABLE IF NOT EXISTS `admin_site` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `description` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `active_from_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `inactive_from_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `lock_from_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_site_category`
--

CREATE TABLE IF NOT EXISTS `admin_site_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_site_id` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_category_id` int(10) unsigned NOT NULL DEFAULT '0',
  `active_from_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `inactive_from_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `system_site_id` (`admin_site_id`),
  KEY `system_category_id` (`admin_category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_site_parent`
--

CREATE TABLE IF NOT EXISTS `admin_site_parent` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_site_id` int(10) unsigned NOT NULL DEFAULT '0',
  `parent_admin_site_id` int(10) unsigned NOT NULL DEFAULT '0',
  `active_from_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `inactive_from_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `system_site_id` (`admin_site_id`),
  KEY `parent_system_site_id` (`parent_admin_site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_site_target`
--

CREATE TABLE IF NOT EXISTS `admin_site_target` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_site_id` int(10) NOT NULL,
  `admin_category_id` int(10) NOT NULL DEFAULT '1',
  `code` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `type` enum('PERCENTAGE','COUNT') NOT NULL DEFAULT 'COUNT',
  `value` double(10,6) NOT NULL,
  `active_from_date` bigint(20) unsigned NOT NULL,
  `inactive_from_date` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='target for each site' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_user`
--

CREATE TABLE IF NOT EXISTS `admin_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `email_address` varchar(128) NOT NULL,
  `password_sha1` varchar(40) NOT NULL,
  `name` varchar(128) NOT NULL,
  `last_login_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `active_from_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `inactive_from_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `lock_from_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `email` (`email_address`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `admin_user`
--

INSERT INTO `admin_user` (`id`, `username`, `email_address`, `password_sha1`, `name`, `last_login_date`, `active_from_date`, `inactive_from_date`, `lock_from_date`) VALUES
(1, 'admin@potentiateglobal.com', 'admin@potentiateglobal.com', 'fc066b43ebac88d44e9d3e72200f9a2187dbb0c8', 'Potentiate Admin', 1418599334, 0, 0, 0),
(41, 'K05337', 'Ante.Grabovac@toyota.com.au', '', '', 1421126180, 1421124912, 0, 0),
(31, 'stephen.burns', 'sburns@cmitoyota.com.au', '', '', 1421124828, 1421124828, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `admin_user_role`
--

CREATE TABLE IF NOT EXISTS `admin_user_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_role_id` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_category_id` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_site_id` int(10) unsigned NOT NULL DEFAULT '0',
  `active_from_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `inactive_from_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `system_user_id` (`admin_user_id`),
  KEY `system_role_id` (`admin_role_id`),
  KEY `system_category_id` (`admin_category_id`),
  KEY `system_site_id` (`admin_site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin_user_role`
--

INSERT INTO `admin_user_role` (`id`, `admin_user_id`, `admin_role_id`, `admin_category_id`, `admin_site_id`, `active_from_date`, `inactive_from_date`) VALUES
(1, 1, 1, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cem_service`
--

CREATE TABLE IF NOT EXISTS `cem_service` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `description` varchar(255) NOT NULL,
  `active_from_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `inactive_from_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cem_service_components`
--

CREATE TABLE IF NOT EXISTS `cem_service_components` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cem_service_id` int(10) unsigned NOT NULL DEFAULT '0',
  `priority` smallint(5) unsigned NOT NULL DEFAULT '0',
  `type` varchar(32) NOT NULL,
  `data` text NOT NULL,
  `data_delimiter` varchar(8) NOT NULL DEFAULT ',',
  PRIMARY KEY (`id`),
  UNIQUE KEY `cem_service_id_priority` (`cem_service_id`,`priority`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cem_survey_alert`
--

CREATE TABLE IF NOT EXISTS `cem_survey_alert` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cem_survey_alert_rule_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cem_survey_alert_rule_name` varchar(32) NOT NULL,
  `cem_survey_alert_rule_description` varchar(255) NOT NULL,
  `survey_id` varchar(150) NOT NULL,
  `closed_date` bigint(20) NOT NULL DEFAULT '0',
  `closed_admin_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `closed_admin_user_name` varchar(128) NOT NULL,
  `closed_admin_user_email_address` varchar(128) NOT NULL,
  `closed_comment` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `system_survey_alert_id` (`cem_survey_alert_rule_id`),
  KEY `closed_system_user_id` (`closed_admin_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='this table stores the alerts that have been generated' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cem_survey_alert_rule`
--

CREATE TABLE IF NOT EXISTS `cem_survey_alert_rule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_id` varchar(30) NOT NULL,
  `name` varchar(32) NOT NULL,
  `description` varchar(255) NOT NULL,
  `rule` varchar(255) NOT NULL,
  `from_name` varchar(128) NOT NULL,
  `from_email_address` varchar(255) NOT NULL,
  `reply_to_name` varchar(128) NOT NULL,
  `reply_to_email_address` varchar(255) NOT NULL,
  `bcc_email_addresses` text NOT NULL,
  `email_subject` varchar(128) NOT NULL,
  `email_body_html` text NOT NULL,
  `email_body_text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cem_survey_alert_rule_user`
--

CREATE TABLE IF NOT EXISTS `cem_survey_alert_rule_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cem_survey_alert_rule_id` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_site_id` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `system_survey_alert_id` (`cem_survey_alert_rule_id`),
  KEY `system_user_id` (`admin_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cem_survey_alert_sent_user`
--

CREATE TABLE IF NOT EXISTS `cem_survey_alert_sent_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cem_survey_alert_id` int(10) unsigned NOT NULL DEFAULT '0',
  `date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `admin_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_user_name` varchar(128) NOT NULL,
  `admin_user_email_address` varchar(255) NOT NULL,
  `read_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cem_survey_appeal`
--

CREATE TABLE IF NOT EXISTS `cem_survey_appeal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `survey_id` varchar(150) NOT NULL,
  `category_name` varchar(128) NOT NULL,
  `close_notification_email_addresses` text NOT NULL COMMENT 'This is the addresses to send the responses to.',
  `status` enum('PENDING','APPROVED','NOT_APPROVED') NOT NULL DEFAULT 'PENDING',
  `open_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `open_admin_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `open_admin_user_name` varchar(128) NOT NULL,
  `open_comments` text NOT NULL,
  `reminder_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `close_date` bigint(20) unsigned NOT NULL,
  `close_admin_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `close_admin_user_name` varchar(128) NOT NULL,
  `close_comments` text NOT NULL,
  `acknowledge_date` bigint(20) unsigned NOT NULL,
  `acknowledge_admin_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `acknowledge_admin_user_name` varchar(128) NOT NULL,
  `acknowledge_comments` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `survey_id` (`survey_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cem_survey_appeal_file`
--

CREATE TABLE IF NOT EXISTS `cem_survey_appeal_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cem_survey_appeal_id` int(10) unsigned NOT NULL,
  `survey_id` varchar(150) NOT NULL,
  `file_name_old` varchar(128) NOT NULL,
  `file_name_new` varchar(64) NOT NULL,
  `file_size` double(20,4) NOT NULL DEFAULT '0.0000',
  `file_type` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cloudrunner_calculation`
--

CREATE TABLE IF NOT EXISTS `cloudrunner_calculation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_id` varchar(30) NOT NULL,
  `table` varchar(64) NOT NULL,
  `priority` smallint(3) unsigned NOT NULL DEFAULT '1',
  `rule` text NOT NULL,
  `field_name` text NOT NULL,
  `field_value` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `job_id` (`job_id`,`table`,`priority`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cloudrunner_exclusion_rule`
--

CREATE TABLE IF NOT EXISTS `cloudrunner_exclusion_rule` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `job_id` varchar(30) NOT NULL,
  `key` varchar(255) NOT NULL,
  `operator` enum('EQUALS','NOT_EQUALS','LIKE','GREATER_THAN','GREATER_THAN_EQUALS','LESS_THAN','LESS_THAN_EQUALS','IN','NOT_IN') NOT NULL DEFAULT 'EQUALS',
  `value` varchar(1024) NOT NULL,
  `type` enum('UNDEFINED','KEY','EMAIL_USERNAME','EMAIL_DOMAIN','EMAIL_ADDRESS','ADDRESS_STREET','ADDRESS_POSTCODE','ADDRESS_SUBURB','ADDRESS_COUNTRY','ADDRESS_POSTAL') NOT NULL DEFAULT 'UNDEFINED',
  `action` enum('UNDEFINED','SEND_EMAIL','SEND_SNAIL_MAIL','EXCLUDE_EMAIL','EXCLUDE_ADDRESS','EXCLUDE_OPT_OUT','EXCLUDE_KEY') NOT NULL DEFAULT 'UNDEFINED',
  PRIMARY KEY (`id`),
  KEY `job_id_key` (`job_id`,`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='this table stores information about exclusion rules' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cloudrunner_sample`
--

CREATE TABLE IF NOT EXISTS `cloudrunner_sample` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_id` varchar(30) NOT NULL,
  `filename` varchar(64) NOT NULL,
  `file_content_sha1` varchar(40) NOT NULL,
  `import_process_date` bigint(20) unsigned NOT NULL,
  `import_process_status` enum('PENDING','PROCESSING','COMPLETED','ERROR') NOT NULL DEFAULT 'PENDING',
  `exclusion_process_date` bigint(20) unsigned NOT NULL,
  `exclusion_process_status` enum('PENDING','PROCESSING','COMPLETED','ERROR') NOT NULL DEFAULT 'PENDING',
  `ml_fields_process_date` bigint(20) unsigned NOT NULL,
  `ml_fields_process_status` enum('PENDING','PROCESSING','COMPLETED','ERROR') NOT NULL DEFAULT 'PENDING',
  `invitation_process_date` bigint(20) unsigned NOT NULL,
  `invitation_process_status` enum('PENDING','PROCESSING','COMPLETED','ERROR') NOT NULL DEFAULT 'PENDING',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sample_id` (`file_content_sha1`),
  UNIQUE KEY `sample_id_2` (`file_content_sha1`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='this table stores information about a sample feed.' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cloudrunner_sample_file_column_format`
--

CREATE TABLE IF NOT EXISTS `cloudrunner_sample_file_column_format` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cloudrunner_sample_file_format_id` int(11) NOT NULL DEFAULT '0',
  `required` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `type` varchar(16) NOT NULL,
  `type_property` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cloudrunner_sample_file_format`
--

CREATE TABLE IF NOT EXISTS `cloudrunner_sample_file_format` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_id` varchar(30) NOT NULL,
  `filename_format` varchar(255) NOT NULL,
  `unknown_column_rule` enum('REJECT_FILE','SKIP_ROW','IMPORT_ROW') NOT NULL DEFAULT 'IMPORT_ROW',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cloudrunner_sample_notification_log`
--

CREATE TABLE IF NOT EXISTS `cloudrunner_sample_notification_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cloudrunner_sample_row_id` int(10) unsigned NOT NULL DEFAULT '0',
  `type` varchar(16) NOT NULL,
  `method` varchar(16) NOT NULL,
  `sent_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cloudrunner_sample_row`
--

CREATE TABLE IF NOT EXISTS `cloudrunner_sample_row` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cloudrunner_sample_id` int(10) unsigned NOT NULL DEFAULT '0',
  `row_key` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `row_number` int(10) unsigned NOT NULL,
  `import_process_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `import_process_status` enum('PENDING','PROCESSING','COMPLETED','ERROR','DUPLICATE') NOT NULL DEFAULT 'PENDING',
  `exclusion_process_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `exclusion_process_status` enum('PENDING','PROCESSING','COMPLETED','ERROR','DUPLICATE') NOT NULL DEFAULT 'PENDING',
  `exclusion_action_status` enum('UNDEFINED','PENDING','SEND_EMAIL','SEND_SNAIL_MAIL','SEND_PHONE','SEND_SMS','EXCLUDE_EMAIL','EXCLUDE_ADDRESS','EXCLUDE_OPT_OUT','EXCLUDE_KEY','ERROR') NOT NULL DEFAULT 'PENDING',
  `ml_fields_process_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `ml_fields_process_status` enum('PENDING','PROCESSING','COMPLETED','ERROR','DUPLICATE') NOT NULL DEFAULT 'PENDING',
  `invitation_process_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `invitation_process_status` enum('PENDING','PROCESSING','COMPLETED','ERROR','DUPLICATE') NOT NULL DEFAULT 'PENDING',
  `invitation_action_status` enum('UNDEFINED','NA','PENDING','TEST_PENDING','TEST_COMPLETED','TEST_ERROR','SENT_EMAIL','SENT_SNAIL_MAIL','SENT_PHONE','SEND_SMS','OPTED_OUT','ERROR') NOT NULL DEFAULT 'PENDING',
  `reminder_process_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `reminder_process_status` enum('PENDING','PROCESSING','COMPLETED','ERROR') NOT NULL,
  `reminder_action_status` enum('UNDEFINED','NA','PENDING','TEST_PENDING','TEST_COMPLETED','TEST_ERROR','SENT_EMAIL','SENT_SNAIL_MAIL','ERROR') NOT NULL,
  `reminder_count` int(11) unsigned NOT NULL DEFAULT '0',
  `bounce_process_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `bounce_action_status` enum('YES','NO','UNKNOWN') NOT NULL DEFAULT 'UNKNOWN',
  PRIMARY KEY (`id`),
  KEY `sample_id` (`cloudrunner_sample_id`),
  KEY `id` (`id`,`cloudrunner_sample_id`,`import_process_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='this table stores information about a row in sample feed.' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cloudrunner_sample_row_data`
--

CREATE TABLE IF NOT EXISTS `cloudrunner_sample_row_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cloudrunner_sample_row_id` int(10) unsigned NOT NULL DEFAULT '0',
  `field_name` varchar(255) NOT NULL,
  `field_value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cloudrunner_sample_row_id` (`cloudrunner_sample_row_id`,`field_name`(50),`field_value`(50))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='this table stores information about a cell in sample feed.' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cloudrunner_survey_invite`
--

CREATE TABLE IF NOT EXISTS `cloudrunner_survey_invite` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_id` varchar(30) NOT NULL,
  `name` varchar(32) NOT NULL,
  `description` varchar(255) NOT NULL,
  `to_name` varchar(128) NOT NULL,
  `to_email_address` varchar(255) NOT NULL,
  `from_name` varchar(128) NOT NULL,
  `from_email_address` varchar(255) NOT NULL,
  `reply_to_name` varchar(128) NOT NULL,
  `reply_to_email_address` varchar(255) NOT NULL,
  `bcc_email_addresses` text NOT NULL,
  `bcc_email_count_maximum` smallint(4) unsigned NOT NULL DEFAULT '0',
  `email_subject` varchar(128) NOT NULL,
  `email_body_html` text NOT NULL,
  `email_body_text` text NOT NULL,
  `is_test_mode` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `is_reminder` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `reminder_timeout` bigint(20) unsigned NOT NULL DEFAULT '0',
  `reminder_count_maximum` tinyint(2) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cloudrunner_survey_replacement`
--

CREATE TABLE IF NOT EXISTS `cloudrunner_survey_replacement` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `job_id` varchar(30) NOT NULL,
  `field_name` varchar(48) NOT NULL,
  `field_value` text NOT NULL,
  `rule_value` text NOT NULL,
  `display_value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `coding_boxes`
--

CREATE TABLE IF NOT EXISTS `coding_boxes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `JOB_ID` varchar(10) NOT NULL DEFAULT '',
  `FIELD_NAME` varchar(12) NOT NULL DEFAULT '',
  `CB_NUM` int(11) NOT NULL DEFAULT '0',
  `STATUS` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `coding_frame`
--

CREATE TABLE IF NOT EXISTS `coding_frame` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CF_KEY` varchar(31) NOT NULL DEFAULT '',
  `FIELD_NAME` varchar(20) NOT NULL DEFAULT '',
  `VALUE` varchar(255) DEFAULT NULL,
  `CODE` int(10) NOT NULL DEFAULT '0',
  `LIBRARY` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_cf_key` (`CF_KEY`),
  KEY `CF_KEY` (`CF_KEY`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `coding_frame_logs`
--

CREATE TABLE IF NOT EXISTS `coding_frame_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `OLD_CF_KEY` varchar(30) NOT NULL DEFAULT '',
  `NEW_CF_KEY` varchar(30) NOT NULL DEFAULT '',
  `FIELD_NAME` varchar(20) NOT NULL DEFAULT '',
  `OLD_VALUE` varchar(255) DEFAULT NULL,
  `NEW_VALUE` varchar(255) DEFAULT NULL,
  `OLD_CODE` int(11) NOT NULL DEFAULT '0',
  `NEW_CODE` int(11) NOT NULL DEFAULT '0',
  `USER_ID` varchar(10) NOT NULL DEFAULT '',
  `TIME_STAMP` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `coding_logs`
--

CREATE TABLE IF NOT EXISTS `coding_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SURVEY_ID` varchar(60) NOT NULL DEFAULT '',
  `USER_ID` varchar(10) NOT NULL DEFAULT '',
  `FIELD_NAME` varchar(10) NOT NULL DEFAULT '',
  `OLD_VALUE` text NOT NULL,
  `NEW_VALUE` text NOT NULL,
  `TIME_STAMP` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CODED` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `core_configuration`
--

CREATE TABLE IF NOT EXISTS `core_configuration` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project` enum('ADMIN','CEM','CORE','CLOUDRUNNER','APPLICATION') NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_name` (`project`,`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='This table contains configurations for projects eg. ADMN' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `core_configuration`
--

INSERT INTO `core_configuration` (`id`, `project`, `name`, `value`) VALUES
(1, 'ADMIN', 'ADMIN_SESSION_EXPIRE_LIMIT_IN_SECONDS', '1800');

-- --------------------------------------------------------

--
-- Table structure for table `core_database_version`
--

CREATE TABLE IF NOT EXISTS `core_database_version` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(32) NOT NULL,
  `change_date` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `version` (`version`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `core_process_heartbeat`
--

CREATE TABLE IF NOT EXISTS `core_process_heartbeat` (
  `id` int(10) unsigned NOT NULL,
  `process_name` varchar(64) NOT NULL,
  `meta_data` varchar(255) NOT NULL,
  `row_number` int(10) unsigned NOT NULL DEFAULT '0',
  `date` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `processor_name` (`process_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `counter`
--

CREATE TABLE IF NOT EXISTS `counter` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SURVEY_ID` varchar(60) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE IF NOT EXISTS `data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `SURVEY_ID` varchar(150) DEFAULT NULL,
  `FIELD_NAME` varchar(48) DEFAULT NULL,
  `FIELD_VALUE` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `SURVEY_ID_2` (`SURVEY_ID`,`FIELD_NAME`),
  KEY `SURVEY_ID` (`SURVEY_ID`),
  KEY `FIELD_NAME` (`FIELD_NAME`),
  KEY `ID_FIELD` (`SURVEY_ID`,`FIELD_NAME`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `data_def`
--

CREATE TABLE IF NOT EXISTS `data_def` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `JOB_ID` varchar(60) NOT NULL,
  `VAR_KEY` varchar(255) NOT NULL,
  `VAR_ALIAS` varchar(255) NOT NULL,
  `RANK` int(5) NOT NULL,
  `VERSION` int(5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `JOB_ID` (`JOB_ID`),
  KEY `RANK` (`RANK`),
  KEY `VAR_KEY` (`VAR_KEY`),
  KEY `VERSION` (`VERSION`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `data_extract`
--

CREATE TABLE IF NOT EXISTS `data_extract` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `JOB_ID` varchar(60) NOT NULL,
  `STATUS` int(2) NOT NULL,
  `COUNT` int(5) NOT NULL,
  `TOTAL` int(5) NOT NULL,
  `TIME_STAMP` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_job_id` (`JOB_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `data_punch`
--

CREATE TABLE IF NOT EXISTS `data_punch` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NAME` varchar(60) NOT NULL DEFAULT '',
  `STATIONS` int(4) NOT NULL DEFAULT '0',
  `DAYS` int(4) NOT NULL DEFAULT '0',
  `DATE` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `email`
--

CREATE TABLE IF NOT EXISTS `email` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `JOB_ID` varchar(30) NOT NULL DEFAULT '',
  `EMAIL_SUBJECT` varchar(255) NOT NULL DEFAULT '',
  `EMAIL_TEXT` text,
  `REMIDER_SUBJECT` varchar(255) NOT NULL DEFAULT '',
  `REMINDER_TEXT` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `extract_order`
--

CREATE TABLE IF NOT EXISTS `extract_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `JOB_ID` varchar(20) NOT NULL DEFAULT '',
  `AORDER` varchar(255) NOT NULL DEFAULT '',
  `TYPE` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `JOB_ID` (`JOB_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `extra_variables`
--

CREATE TABLE IF NOT EXISTS `extra_variables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `JOB_ID` varchar(10) NOT NULL DEFAULT '',
  `FIELD_NAME` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `frame_links`
--

CREATE TABLE IF NOT EXISTS `frame_links` (
  `LINK_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `FIELD_NAME` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`LINK_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `insights_brand`
--

CREATE TABLE IF NOT EXISTS `insights_brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(255) NOT NULL,
  `is_default_brand` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=52 ;

--
-- Dumping data for table `insights_brand`
--

INSERT INTO `insights_brand` (`id`, `brand_name`, `is_default_brand`) VALUES
(1, 'KIA', 0),
(11, 'Toyota', 1),
(21, 'Honda', 0),
(31, 'Bajaj', 0),
(41, 'BMW', 0),
(51, 'Hyundai', 0);

-- --------------------------------------------------------

--
-- Table structure for table `insights_library_file`
--

CREATE TABLE IF NOT EXISTS `insights_library_file` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `date_uploaded` datetime NOT NULL,
  `tags` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1302 ;

--
-- Dumping data for table `insights_library_file`
--

INSERT INTO `insights_library_file` (`id`, `name`, `filename`, `location`, `type`, `date_uploaded`, `tags`) VALUES
(1131, 'medianame', '549268ea95199_Book1.csv', '/var/www/tips_2/library/public/upload', 'application/vnd.ms-excel', '2014-12-18 16:40:58', '[2014,"check","monthly","data","toyota","brand","month","model","new","make"]'),
(1141, 'lib service test', '5492692163425_big.docx', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2014-12-18 16:41:53', '["build","eclipse","using","workbench","simultaneous","license","starling","free","mediawiki","general"]'),
(1231, 'link test', '54975312ae476_big.docx', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2014-12-22 10:09:06', ''),
(1241, 'test1', '54979b4a5ba3f_big.docx', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2014-12-22 15:17:14', '["General Public License","using","one","build","GNU"]'),
(1251, 'test22', '5497559339c69_big.docx', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2014-12-22 10:19:47', ''),
(1261, 'auto select model', '54979705a6063_big.docx', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2014-12-22 14:59:01', '["General Public License","using","one","build","GNU"]'),
(1081, 'testing n', '5492596672a0d_Book1.csv', '/var/www/tips_2/library/public/upload', 'application/vnd.ms-excel', '2014-12-18 15:34:46', ''),
(1281, 'test', '5497973511ff0_big.docx', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2014-12-22 14:59:49', '["General Public License","using","Corolla","build","one"]'),
(1291, 'yrdy', '5497971db372d_big.docx', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2014-12-22 14:59:25', ''),
(1301, 'testing after new orm build', '5497a6eb4f18b_big1.docx', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2014-12-22 16:07:06', '[]'),
(851, 'auto populate tags', '54979765b9c7e_big.docx', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2014-12-22 15:00:37', '[]'),
(1211, 'test123', '549751a51560e_big.docx', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2014-12-22 10:03:01', '["General Public License","using","one","build","GNU"]'),
(1221, 'from ui', '549751e1c0f6e_big.docx', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2014-12-22 10:04:01', ''),
(1191, 'test', '549790f624e7a_big.docx', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2014-12-22 14:33:10', '["General Public License","using","one","build","GNU"]'),
(1201, 'link test', '', '', 'link', '2014-12-22 09:56:27', '["General Public License","using","one","build","GNU"]'),
(991, 'rwar', '549240f9a6c9f_big.docx', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2014-12-18 13:50:33', '[]'),
(1271, 'auto', '549795c829386_big.docx', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2014-12-22 14:53:44', '[]'),
(1011, 'newfileupload', '549241e569a39_big.docx', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2014-12-18 13:54:29', '[]'),
(1181, 'category fetched form db', '549375b135054_big.docx', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2014-12-19 11:47:45', '["General Public License","using","one","build","GNU"]');

-- --------------------------------------------------------

--
-- Table structure for table `insights_library_file_categories`
--

CREATE TABLE IF NOT EXISTS `insights_library_file_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insights_library_file_id` int(11) NOT NULL,
  `insights_category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_insights_library_file_id` (`insights_library_file_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2372 ;

--
-- Dumping data for table `insights_library_file_categories`
--

INSERT INTO `insights_library_file_categories` (`id`, `insights_library_file_id`, `insights_category_id`) VALUES
(2291, 1241, 331),
(2281, 1241, 321),
(2181, 1011, 321),
(2201, 1201, 321),
(2171, 1141, 361),
(2191, 1191, 321),
(2271, 1231, 361),
(2261, 1231, 341),
(2251, 1231, 321),
(2241, 1221, 361),
(2161, 1141, 351),
(2151, 1141, 341),
(2121, 1131, 361),
(2331, 1251, 341),
(2231, 1221, 341),
(2111, 1131, 351),
(2221, 1221, 321),
(2211, 1211, 321),
(2341, 1251, 351),
(2321, 1251, 331),
(2101, 1131, 341),
(2091, 1131, 331),
(2141, 1141, 331),
(2131, 1141, 321),
(2311, 1251, 321),
(2081, 1131, 321),
(2301, 1241, 341),
(2051, 1181, 361),
(2041, 1181, 321),
(2351, 1261, 321),
(2361, 1301, 321),
(2371, 1301, 331);

-- --------------------------------------------------------

--
-- Table structure for table `insights_library_file_models`
--

CREATE TABLE IF NOT EXISTS `insights_library_file_models` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insights_library_file_id` int(12) NOT NULL,
  `insights_model_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_insights_library_file_id` (`insights_library_file_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1672 ;

--
-- Dumping data for table `insights_library_file_models`
--

INSERT INTO `insights_library_file_models` (`id`, `insights_library_file_id`, `insights_model_id`) VALUES
(1391, 1201, 261),
(1351, 1181, 111),
(1411, 1221, 31),
(1361, 1181, 61),
(1401, 1211, 31),
(1321, 1181, 91),
(1381, 1181, 181),
(1331, 1181, 211),
(1371, 1181, 81),
(1311, 1181, 31),
(1421, 1221, 41),
(1341, 1181, 301),
(1491, 1221, 301),
(1601, 1251, 91),
(1541, 1241, 81),
(1481, 1221, 251),
(1591, 1251, 81),
(1581, 1251, 41),
(1531, 1241, 31),
(1521, 1231, 141),
(1461, 1221, 161),
(1451, 1221, 141),
(1441, 1221, 91),
(1431, 1221, 81),
(1571, 1251, 31),
(1561, 1241, 231),
(1551, 1241, 141),
(1511, 1231, 81),
(1501, 1231, 31),
(1471, 1221, 231),
(1611, 1251, 141),
(1621, 1251, 161),
(1631, 1251, 231),
(1641, 1251, 251),
(1651, 1251, 301),
(1661, 1191, 31),
(1671, 1281, 61);

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE IF NOT EXISTS `job` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `JOB_ID` varchar(30) NOT NULL DEFAULT '',
  `JOB_NAME` varchar(30) NOT NULL DEFAULT '',
  `JOB_TYPE` varchar(30) NOT NULL DEFAULT '',
  `CLIENT_NAME` varchar(30) NOT NULL DEFAULT '',
  `FILE_NAME` varchar(50) NOT NULL DEFAULT '',
  `ARCHIVED` tinyint(1) DEFAULT '0',
  `DURATION` int(5) NOT NULL DEFAULT '0',
  `MODIFIED` varchar(50) NOT NULL DEFAULT '',
  `ALLOWED_ATTEMPTS` tinyint(2) NOT NULL DEFAULT '1',
  `ATTEMPTS_POLICY` tinyint(2) NOT NULL DEFAULT '1',
  `REP_PASSWORD` varchar(12) DEFAULT 'guest',
  `REP_USERNAME` varchar(60) DEFAULT NULL,
  `sample_filename_prefix` varchar(64) NOT NULL,
  `sample_row_keys` varchar(64) NOT NULL,
  `sample_email_key` varchar(64) NOT NULL,
  `sample_address_keys` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_job_id` (`JOB_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `job_options`
--

CREATE TABLE IF NOT EXISTS `job_options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `JOB_ID` varchar(30) DEFAULT NULL,
  `QCON` int(1) DEFAULT NULL,
  `NOTES` int(1) DEFAULT NULL,
  `PNUM` int(1) DEFAULT NULL,
  `QNUM` int(1) DEFAULT NULL,
  `DEBUG` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `kmapp_import`
--

CREATE TABLE IF NOT EXISTS `kmapp_import` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `file_identifier` bigint(20) unsigned NOT NULL,
  `original_file_name` text NOT NULL,
  `processed_file_location` text NOT NULL,
  `processed_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `kmapp_import_summary`
--

CREATE TABLE IF NOT EXISTS `kmapp_import_summary` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `file_identifier` bigint(20) unsigned NOT NULL,
  `from_date` bigint(20) unsigned NOT NULL,
  `to_date` bigint(20) unsigned NOT NULL,
  `segment` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `enquiry` int(10) unsigned NOT NULL,
  `sales` int(10) unsigned NOT NULL,
  `metric` varchar(255) NOT NULL,
  `metric_value` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3721 ;

--
-- Dumping data for table `kmapp_import_summary`
--

INSERT INTO `kmapp_import_summary` (`id`, `file_identifier`, `from_date`, `to_date`, `segment`, `model`, `enquiry`, `sales`, `metric`, `metric_value`) VALUES
(1, 0, 1396270800, 1404136799, 'Brand', 'Toyota', 0, 0, 'Brand Preference (Q3B)', 24),
(11, 0, 1404136800, 1412085599, 'Brand', 'Toyota', 0, 0, 'Brand Preference (Q3B)', 23),
(21, 0, 1396270800, 1404136799, 'Brand', 'Mazda', 0, 0, 'Brand Preference (Q3B)', 10),
(31, 0, 1404136800, 1412085599, 'Brand', 'Mazda', 0, 0, 'Brand Preference (Q3B)', 12),
(41, 0, 1396270800, 1404136799, 'Brand', 'Honda', 0, 0, 'Brand Preference (Q3B)', 6),
(51, 0, 1404136800, 1412085599, 'Brand', 'Honda', 0, 0, 'Brand Preference (Q3B)', 6),
(61, 0, 1396270800, 1404136799, 'Brand', 'Volkswagen', 0, 0, 'Brand Preference (Q3B)', 8),
(71, 0, 1404136800, 1412085599, 'Brand', 'Volkswagen', 0, 0, 'Brand Preference (Q3B)', 7),
(81, 0, 1396270800, 1404136799, 'Brand', 'Holden', 0, 0, 'Brand Preference (Q3B)', 10),
(91, 0, 1404136800, 1412085599, 'Brand', 'Holden', 0, 0, 'Brand Preference (Q3B)', 9),
(101, 0, 1396270800, 1404136799, 'Brand', 'Subaru', 0, 0, 'Brand Preference (Q3B)', 5),
(111, 0, 1404136800, 1412085599, 'Brand', 'Subaru', 0, 0, 'Brand Preference (Q3B)', 5),
(121, 0, 1396270800, 1404136799, 'Brand', 'Ford', 0, 0, 'Brand Preference (Q3B)', 6),
(131, 0, 1404136800, 1412085599, 'Brand', 'Ford', 0, 0, 'Brand Preference (Q3B)', 7),
(141, 0, 1396270800, 1404136799, 'Brand', 'Hyundai', 0, 0, 'Brand Preference (Q3B)', 7),
(151, 0, 1404136800, 1412085599, 'Brand', 'Hyundai', 0, 0, 'Brand Preference (Q3B)', 9),
(161, 0, 1396270800, 1404136799, 'Brand', 'Nissan', 0, 0, 'Brand Preference (Q3B)', 5),
(171, 0, 1404136800, 1412085599, 'Brand', 'Nissan', 0, 0, 'Brand Preference (Q3B)', 4),
(181, 0, 1396270800, 1404136799, 'Brand', 'Mitsubishi', 0, 0, 'Brand Preference (Q3B)', 3),
(191, 0, 1404136800, 1412085599, 'Brand', 'Mitsubishi', 0, 0, 'Brand Preference (Q3B)', 3),
(201, 0, 1396270800, 1404136799, 'Light', 'Toyota Yaris', 0, 0, 'Brand Preference (Q2AX2)', 7),
(211, 0, 1404136800, 1412085599, 'Light', 'Toyota Yaris', 0, 0, 'Brand Preference (Q2AX2)', 8),
(221, 0, 1396270800, 1404136799, 'Light', 'Mazda 2', 0, 0, 'Brand Preference (Q2AX2)', 4),
(231, 0, 1404136800, 1412085599, 'Light', 'Mazda 2', 0, 0, 'Brand Preference (Q2AX2)', 3),
(241, 0, 1396270800, 1404136799, 'Light', 'Suzuki Swift', 0, 0, 'Brand Preference (Q2AX2)', 5),
(251, 0, 1404136800, 1412085599, 'Light', 'Suzuki Swift', 0, 0, 'Brand Preference (Q2AX2)', 5),
(261, 0, 1396270800, 1404136799, 'Light', 'Hyundai i20', 0, 0, 'Brand Preference (Q2AX2)', 4),
(271, 0, 1404136800, 1412085599, 'Light', 'Hyundai i20', 0, 0, 'Brand Preference (Q2AX2)', 3),
(281, 0, 1396270800, 1404136799, 'Light', 'Honda Jazz', 0, 0, 'Brand Preference (Q2AX2)', 4),
(291, 0, 1404136800, 1412085599, 'Light', 'Honda Jazz', 0, 0, 'Brand Preference (Q2AX2)', 5),
(301, 0, 1396270800, 1404136799, 'Light', 'Ford Fiesta', 0, 0, 'Brand Preference (Q2AX2)', 2),
(311, 0, 1404136800, 1412085599, 'Light', 'Ford Fiesta', 0, 0, 'Brand Preference (Q2AX2)', 3),
(321, 0, 1396270800, 1404136799, 'Light', 'Toyota Prius c', 0, 0, 'Brand Preference (Q2AX2)', 2),
(331, 0, 1404136800, 1412085599, 'Light', 'Toyota Prius c', 0, 0, 'Brand Preference (Q2AX2)', 3),
(341, 0, 1396270800, 1404136799, 'Light', 'Volkswagen Polo', 0, 0, 'Brand Preference (Q2AX2)', 2),
(351, 0, 1404136800, 1412085599, 'Light', 'Volkswagen Polo', 0, 0, 'Brand Preference (Q2AX2)', 3),
(361, 0, 1396270800, 1404136799, 'Light', 'Holden Barina', 0, 0, 'Brand Preference (Q2AX2)', 5),
(371, 0, 1404136800, 1412085599, 'Light', 'Holden Barina', 0, 0, 'Brand Preference (Q2AX2)', 4),
(381, 0, 1396270800, 1404136799, 'Light', 'Hyundai Accent', 0, 0, 'Brand Preference (Q2AX2)', 2),
(391, 0, 1404136800, 1412085599, 'Light', 'Hyundai Accent', 0, 0, 'Brand Preference (Q2AX2)', 2),
(401, 0, 1396270800, 1404136799, 'Light', 'Kia Rio', 0, 0, 'Brand Preference (Q2AX2)', 3),
(411, 0, 1404136800, 1412085599, 'Light', 'Kia Rio', 0, 0, 'Brand Preference (Q2AX2)', 3),
(421, 0, 1396270800, 1404136799, 'Light', 'Honda City', 0, 0, 'Brand Preference (Q2AX2)', 2),
(431, 0, 1404136800, 1412085599, 'Light', 'Honda City', 0, 0, 'Brand Preference (Q2AX2)', 2),
(441, 0, 1396270800, 1404136799, 'Light', 'Renault Clio', 0, 0, 'Brand Preference (Q2AX2)', 1),
(451, 0, 1404136800, 1412085599, 'Light', 'Renault Clio', 0, 0, 'Brand Preference (Q2AX2)', 1),
(461, 0, 1396270800, 1404136799, 'Light', 'Peugeot 208', 0, 0, 'Brand Preference (Q2AX2)', 1),
(471, 0, 1404136800, 1412085599, 'Light', 'Peugeot 208', 0, 0, 'Brand Preference (Q2AX2)', 0),
(481, 0, 1396270800, 1404136799, 'Light', 'Nissan Almera', 0, 0, 'Brand Preference (Q2AX2)', 0),
(491, 0, 1404136800, 1412085599, 'Light', 'Nissan Almera', 0, 0, 'Brand Preference (Q2AX2)', 0),
(501, 0, 1396270800, 1404136799, 'Light', 'Fiat Punto', 0, 0, 'Brand Preference (Q2AX2)', 0),
(511, 0, 1404136800, 1412085599, 'Light', 'Fiat Punto', 0, 0, 'Brand Preference (Q2AX2)', 0),
(521, 0, 1396270800, 1404136799, 'Light', 'Skoda Fabia', 0, 0, 'Brand Preference (Q2AX2)', 0),
(531, 0, 1404136800, 1412085599, 'Light', 'Skoda Fabia', 0, 0, 'Brand Preference (Q2AX2)', 0),
(541, 0, 1396270800, 1404136799, 'Small', 'Mazda 3', 0, 0, 'Brand Preference (Q2AX2)', 9),
(551, 0, 1404136800, 1412085599, 'Small', 'Mazda 3', 0, 0, 'Brand Preference (Q2AX2)', 11),
(561, 0, 1396270800, 1404136799, 'Small', 'Toyota Corolla', 0, 0, 'Brand Preference (Q2AX2)', 14),
(571, 0, 1404136800, 1412085599, 'Small', 'Toyota Corolla', 0, 0, 'Brand Preference (Q2AX2)', 13),
(581, 0, 1396270800, 1404136799, 'Small', 'Volkswagen Golf', 0, 0, 'Brand Preference (Q2AX2)', 5),
(591, 0, 1404136800, 1412085599, 'Small', 'Volkswagen Golf', 0, 0, 'Brand Preference (Q2AX2)', 4),
(601, 0, 1396270800, 1404136799, 'Small', 'Hyundai i30', 0, 0, 'Brand Preference (Q2AX2)', 7),
(611, 0, 1404136800, 1412085599, 'Small', 'Hyundai i30', 0, 0, 'Brand Preference (Q2AX2)', 7),
(621, 0, 1396270800, 1404136799, 'Small', 'Honda Civic', 0, 0, 'Brand Preference (Q2AX2)', 3),
(631, 0, 1404136800, 1412085599, 'Small', 'Honda Civic', 0, 0, 'Brand Preference (Q2AX2)', 2),
(641, 0, 1396270800, 1404136799, 'Small', 'Holden Cruze', 0, 0, 'Brand Preference (Q2AX2)', 5),
(651, 0, 1404136800, 1412085599, 'Small', 'Holden Cruze', 0, 0, 'Brand Preference (Q2AX2)', 5),
(661, 0, 1396270800, 1404136799, 'Small', 'Ford Focus', 0, 0, 'Brand Preference (Q2AX2)', 3),
(671, 0, 1404136800, 1412085599, 'Small', 'Ford Focus', 0, 0, 'Brand Preference (Q2AX2)', 3),
(681, 0, 1396270800, 1404136799, 'Small', 'Toyota Prius', 0, 0, 'Brand Preference (Q2AX2)', 2),
(691, 0, 1404136800, 1412085599, 'Small', 'Toyota Prius', 0, 0, 'Brand Preference (Q2AX2)', 2),
(701, 0, 1396270800, 1404136799, 'Small', 'Subaru Impreza', 0, 0, 'Brand Preference (Q2AX2)', 1),
(711, 0, 1404136800, 1412085599, 'Small', 'Subaru Impreza', 0, 0, 'Brand Preference (Q2AX2)', 1),
(721, 0, 1396270800, 1404136799, 'Small', 'Mitsubishi Lancer', 0, 0, 'Brand Preference (Q2AX2)', 2),
(731, 0, 1404136800, 1412085599, 'Small', 'Mitsubishi Lancer', 0, 0, 'Brand Preference (Q2AX2)', 2),
(741, 0, 1396270800, 1404136799, 'Small', 'Hyundai Elantra', 0, 0, 'Brand Preference (Q2AX2)', 2),
(751, 0, 1404136800, 1412085599, 'Small', 'Hyundai Elantra', 0, 0, 'Brand Preference (Q2AX2)', 2),
(761, 0, 1396270800, 1404136799, 'Small', 'Toyota Prius v', 0, 0, 'Brand Preference (Q2AX2)', 0),
(771, 0, 1404136800, 1412085599, 'Small', 'Toyota Prius v', 0, 0, 'Brand Preference (Q2AX2)', 0),
(781, 0, 1396270800, 1404136799, 'Small', 'Nissan Pulsar', 0, 0, 'Brand Preference (Q2AX2)', 1),
(791, 0, 1404136800, 1412085599, 'Small', 'Nissan Pulsar', 0, 0, 'Brand Preference (Q2AX2)', 2),
(801, 0, 1396270800, 1404136799, 'Small', 'Volkswagen Beetle', 0, 0, 'Brand Preference (Q2AX2)', 1),
(811, 0, 1404136800, 1412085599, 'Small', 'Volkswagen Beetle', 0, 0, 'Brand Preference (Q2AX2)', 1),
(821, 0, 1396270800, 1404136799, 'Small', 'Renault Megane', 0, 0, 'Brand Preference (Q2AX2)', 1),
(831, 0, 1404136800, 1412085599, 'Small', 'Renault Megane', 0, 0, 'Brand Preference (Q2AX2)', 1),
(841, 0, 1396270800, 1404136799, 'Small', 'Suzuki SX4', 0, 0, 'Brand Preference (Q2AX2)', 0),
(851, 0, 1404136800, 1412085599, 'Small', 'Suzuki SX4', 0, 0, 'Brand Preference (Q2AX2)', 0),
(861, 0, 1396270800, 1404136799, 'Small', 'Kia Cerato', 0, 0, 'Brand Preference (Q2AX2)', 1),
(871, 0, 1404136800, 1412085599, 'Small', 'Kia Cerato', 0, 0, 'Brand Preference (Q2AX2)', 1),
(881, 0, 1396270800, 1404136799, 'Small', 'Peugeot 308', 0, 0, 'Brand Preference (Q2AX2)', 1),
(891, 0, 1404136800, 1412085599, 'Small', 'Peugeot 308', 0, 0, 'Brand Preference (Q2AX2)', 0),
(901, 0, 1396270800, 1404136799, 'Small', 'Toyota Rukus', 0, 0, 'Brand Preference (Q2AX2)', 0),
(911, 0, 1404136800, 1412085599, 'Small', 'Toyota Rukus', 0, 0, 'Brand Preference (Q2AX2)', 0),
(921, 0, 1396270800, 1404136799, 'Small', 'Holden Volt', 0, 0, 'Brand Preference (Q2AX2)', 0),
(931, 0, 1404136800, 1412085599, 'Small', 'Holden Volt', 0, 0, 'Brand Preference (Q2AX2)', 0),
(941, 0, 1396270800, 1404136799, 'Small', 'Honda Civic Hybrid', 0, 0, 'Brand Preference (Q2AX2)', 1),
(951, 0, 1404136800, 1412085599, 'Small', 'Honda Civic Hybrid', 0, 0, 'Brand Preference (Q2AX2)', 1),
(961, 0, 1396270800, 1404136799, 'Small', 'Chery J3', 0, 0, 'Brand Preference (Q2AX2)', 0),
(971, 0, 1404136800, 1412085599, 'Small', 'Chery J3', 0, 0, 'Brand Preference (Q2AX2)', 0),
(981, 0, 1396270800, 1404136799, 'Small', 'Nissan Leaf', 0, 0, 'Brand Preference (Q2AX2)', 0),
(991, 0, 1404136800, 1412085599, 'Small', 'Nissan Leaf', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1001, 0, 1396270800, 1404136799, 'Small', 'Honda Insight', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1011, 0, 1404136800, 1412085599, 'Small', 'Honda Insight', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1021, 0, 1396270800, 1404136799, 'Medium', 'Mazda 6', 0, 0, 'Brand Preference (Q2AX2)', 8),
(1031, 0, 1404136800, 1412085599, 'Medium', 'Mazda 6', 0, 0, 'Brand Preference (Q2AX2)', 10),
(1041, 0, 1396270800, 1404136799, 'Medium', 'Toyota Camry', 0, 0, 'Brand Preference (Q2AX2)', 12),
(1051, 0, 1404136800, 1412085599, 'Medium', 'Toyota Camry', 0, 0, 'Brand Preference (Q2AX2)', 12),
(1061, 0, 1396270800, 1404136799, 'Medium', 'Honda Accord', 0, 0, 'Brand Preference (Q2AX2)', 2),
(1071, 0, 1404136800, 1412085599, 'Medium', 'Honda Accord', 0, 0, 'Brand Preference (Q2AX2)', 4),
(1081, 0, 1396270800, 1404136799, 'Medium', 'Toyota Camry Hybrid', 0, 0, 'Brand Preference (Q2AX2)', 7),
(1091, 0, 1404136800, 1412085599, 'Medium', 'Toyota Camry Hybrid', 0, 0, 'Brand Preference (Q2AX2)', 5),
(1101, 0, 1396270800, 1404136799, 'Medium', 'Honda Accord (Euro)', 0, 0, 'Brand Preference (Q2AX2)', 5),
(1111, 0, 1404136800, 1412085599, 'Medium', 'Honda Accord (Euro)', 0, 0, 'Brand Preference (Q2AX2)', 3),
(1121, 0, 1396270800, 1404136799, 'Medium', 'Hyundai i40', 0, 0, 'Brand Preference (Q2AX2)', 7),
(1131, 0, 1404136800, 1412085599, 'Medium', 'Hyundai i40', 0, 0, 'Brand Preference (Q2AX2)', 3),
(1141, 0, 1396270800, 1404136799, 'Medium', 'Volkswagen Passat', 0, 0, 'Brand Preference (Q2AX2)', 2),
(1151, 0, 1404136800, 1412085599, 'Medium', 'Volkswagen Passat', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1161, 0, 1396270800, 1404136799, 'Medium', 'Ford Mondeo', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1171, 0, 1404136800, 1412085599, 'Medium', 'Ford Mondeo', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1181, 0, 1396270800, 1404136799, 'Medium', 'Subaru Liberty', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1191, 0, 1404136800, 1412085599, 'Medium', 'Subaru Liberty', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1201, 0, 1396270800, 1404136799, 'Medium', 'Volkswagen Jetta', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1211, 0, 1404136800, 1412085599, 'Medium', 'Volkswagen Jetta', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1221, 0, 1396270800, 1404136799, 'Medium', 'Holden Malibu', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1231, 0, 1404136800, 1412085599, 'Medium', 'Holden Malibu', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1241, 0, 1396270800, 1404136799, 'Medium', 'Hyundai Sonata', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1251, 0, 1404136800, 1412085599, 'Medium', 'Hyundai Sonata', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1261, 0, 1396270800, 1404136799, 'Medium', 'Skoda Octavia', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1271, 0, 1404136800, 1412085599, 'Medium', 'Skoda Octavia', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1281, 0, 1396270800, 1404136799, 'Medium', 'Citroen C5', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1291, 0, 1404136800, 1412085599, 'Medium', 'Citroen C5', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1301, 0, 1396270800, 1404136799, 'Medium', 'Kia Optima', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1311, 0, 1404136800, 1412085599, 'Medium', 'Kia Optima', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1321, 0, 1396270800, 1404136799, 'Medium', 'Suzuki Kizashi', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1331, 0, 1404136800, 1412085599, 'Medium', 'Suzuki Kizashi', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1341, 0, 1396270800, 1404136799, 'Medium', 'Renault Latitude', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1351, 0, 1404136800, 1412085599, 'Medium', 'Renault Latitude', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1361, 0, 1396270800, 1404136799, 'Medium', 'Chrysler 200', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1371, 0, 1404136800, 1412085599, 'Medium', 'Chrysler 200', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1381, 0, 1396270800, 1404136799, 'Large', 'Holden Commodore', 0, 0, 'Brand Preference (Q2AX2)', 21),
(1391, 0, 1404136800, 1412085599, 'Large', 'Holden Commodore', 0, 0, 'Brand Preference (Q2AX2)', 26),
(1401, 0, 1396270800, 1404136799, 'Large', 'Holden Caprice', 0, 0, 'Brand Preference (Q2AX2)', 6),
(1411, 0, 1404136800, 1412085599, 'Large', 'Holden Caprice', 0, 0, 'Brand Preference (Q2AX2)', 4),
(1421, 0, 1396270800, 1404136799, 'Large', 'Ford Falcon', 0, 0, 'Brand Preference (Q2AX2)', 10),
(1431, 0, 1404136800, 1412085599, 'Large', 'Ford Falcon', 0, 0, 'Brand Preference (Q2AX2)', 12),
(1441, 0, 1396270800, 1404136799, 'Large', 'Toyota Aurion', 0, 0, 'Brand Preference (Q2AX2)', 5),
(1451, 0, 1404136800, 1412085599, 'Large', 'Toyota Aurion', 0, 0, 'Brand Preference (Q2AX2)', 8),
(1461, 0, 1396270800, 1404136799, 'Large', 'Volkswagen Passat CC', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1471, 0, 1404136800, 1412085599, 'Large', 'Volkswagen Passat CC', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1481, 0, 1396270800, 1404136799, 'Large', 'Chrysler 300C', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1491, 0, 1404136800, 1412085599, 'Large', 'Chrysler 300C', 0, 0, 'Brand Preference (Q2AX2)', 3),
(1501, 0, 1396270800, 1404136799, 'Large', 'Nissan Maxima', 0, 0, 'Brand Preference (Q2AX2)', 2),
(1511, 0, 1404136800, 1412085599, 'Large', 'Nissan Maxima', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1521, 0, 1396270800, 1404136799, 'Large', 'Nissan Altima', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1531, 0, 1404136800, 1412085599, 'Large', 'Nissan Altima', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1541, 0, 1396270800, 1404136799, 'Large', 'Skoda Superb', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1551, 0, 1404136800, 1412085599, 'Large', 'Skoda Superb', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1561, 0, 1396270800, 1404136799, 'Compact SUV (S5)', 'Toyota RAV4', 0, 0, 'Brand Preference (Q2AX2)', 9),
(1571, 0, 1404136800, 1412085599, 'Compact SUV (S5)', 'Toyota RAV4', 0, 0, 'Brand Preference (Q2AX2)', 9),
(1581, 0, 1396270800, 1404136799, 'Compact SUV (S5)', 'Mazda CX-5', 0, 0, 'Brand Preference (Q2AX2)', 6),
(1591, 0, 1404136800, 1412085599, 'Compact SUV (S5)', 'Mazda CX-5', 0, 0, 'Brand Preference (Q2AX2)', 9),
(1601, 0, 1396270800, 1404136799, 'Compact SUV (S5)', 'Honda CR-V', 0, 0, 'Brand Preference (Q2AX2)', 5),
(1611, 0, 1404136800, 1412085599, 'Compact SUV (S5)', 'Honda CR-V', 0, 0, 'Brand Preference (Q2AX2)', 5),
(1621, 0, 1396270800, 1404136799, 'Compact SUV (S5)', 'Subaru Forester', 0, 0, 'Brand Preference (Q2AX2)', 5),
(1631, 0, 1404136800, 1412085599, 'Compact SUV (S5)', 'Subaru Forester', 0, 0, 'Brand Preference (Q2AX2)', 8),
(1641, 0, 1396270800, 1404136799, 'Compact SUV (S5)', 'Hyundai ix35', 0, 0, 'Brand Preference (Q2AX2)', 2),
(1651, 0, 1404136800, 1412085599, 'Compact SUV (S5)', 'Hyundai ix35', 0, 0, 'Brand Preference (Q2AX2)', 6),
(1661, 0, 1396270800, 1404136799, 'Compact SUV (S5)', 'Jeep Wrangler', 0, 0, 'Brand Preference (Q2AX2)', 3),
(1671, 0, 1404136800, 1412085599, 'Compact SUV (S5)', 'Jeep Wrangler', 0, 0, 'Brand Preference (Q2AX2)', 2),
(1681, 0, 1396270800, 1404136799, 'Compact SUV (S5)', 'Volkswagen Tiguan', 0, 0, 'Brand Preference (Q2AX2)', 3),
(1691, 0, 1404136800, 1412085599, 'Compact SUV (S5)', 'Volkswagen Tiguan', 0, 0, 'Brand Preference (Q2AX2)', 2),
(1701, 0, 1396270800, 1404136799, 'Compact SUV (S5)', 'Nissan X-Trail', 0, 0, 'Brand Preference (Q2AX2)', 6),
(1711, 0, 1404136800, 1412085599, 'Compact SUV (S5)', 'Nissan X-Trail', 0, 0, 'Brand Preference (Q2AX2)', 3),
(1721, 0, 1396270800, 1404136799, 'Compact SUV (S5)', 'Holden Captiva', 0, 0, 'Brand Preference (Q2AX2)', 4),
(1731, 0, 1404136800, 1412085599, 'Compact SUV (S5)', 'Holden Captiva', 0, 0, 'Brand Preference (Q2AX2)', 2),
(1741, 0, 1396270800, 1404136799, 'Compact SUV (S5)', 'Kia Sportage', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1751, 0, 1404136800, 1412085599, 'Compact SUV (S5)', 'Kia Sportage', 0, 0, 'Brand Preference (Q2AX2)', 2),
(1761, 0, 1396270800, 1404136799, 'Compact SUV (S5)', 'LandRover Freelander', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1771, 0, 1404136800, 1412085599, 'Compact SUV (S5)', 'LandRover Freelander', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1781, 0, 1396270800, 1404136799, 'Compact SUV (S5)', 'Mitsubishi Outlander', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1791, 0, 1404136800, 1412085599, 'Compact SUV (S5)', 'Mitsubishi Outlander', 0, 0, 'Brand Preference (Q2AX2)', 2),
(1801, 0, 1396270800, 1404136799, 'Compact SUV (S5)', 'Jeep Compass', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1811, 0, 1404136800, 1412085599, 'Compact SUV (S5)', 'Jeep Compass', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1821, 0, 1396270800, 1404136799, 'Compact SUV (S5)', 'Suzuki Grand Vitara', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1831, 0, 1404136800, 1412085599, 'Compact SUV (S5)', 'Suzuki Grand Vitara', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1841, 0, 1396270800, 1404136799, 'Compact SUV (S5)', 'Jeep Patriot', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1851, 0, 1404136800, 1412085599, 'Compact SUV (S5)', 'Jeep Patriot', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1861, 0, 1396270800, 1404136799, 'Compact SUV (S5)', 'Ford Kuga', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1871, 0, 1404136800, 1412085599, 'Compact SUV (S5)', 'Ford Kuga', 0, 0, 'Brand Preference (Q2AX2)', 1),
(1881, 0, 1396270800, 1404136799, 'Compact SUV (S5)', 'Great Wall X200', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1891, 0, 1404136800, 1412085599, 'Compact SUV (S5)', 'Great Wall X200', 0, 0, 'Brand Preference (Q2AX2)', 0),
(1901, 0, 1396270800, 1404136799, 'Med Soft SUV (S6)', 'Toyota Kluger', 0, 0, 'Brand Preference (Q2AX2)', 16),
(1911, 0, 1404136800, 1412085599, 'Med Soft SUV (S6)', 'Toyota Kluger', 0, 0, 'Brand Preference (Q2AX2)', 13),
(1921, 0, 1396270800, 1404136799, 'Med Soft SUV (S6)', 'Ford Territory', 0, 0, 'Brand Preference (Q2AX2)', 11),
(1931, 0, 1404136800, 1412085599, 'Med Soft SUV (S6)', 'Ford Territory', 0, 0, 'Brand Preference (Q2AX2)', 9),
(1941, 0, 1396270800, 1404136799, 'Med Soft SUV (S6)', 'Subaru Outback', 0, 0, 'Brand Preference (Q2AX2)', 4),
(1951, 0, 1404136800, 1412085599, 'Med Soft SUV (S6)', 'Subaru Outback', 0, 0, 'Brand Preference (Q2AX2)', 5),
(1961, 0, 1396270800, 1404136799, 'Med Soft SUV (S6)', 'Mazda CX-9', 0, 0, 'Brand Preference (Q2AX2)', 6),
(1971, 0, 1404136800, 1412085599, 'Med Soft SUV (S6)', 'Mazda CX-9', 0, 0, 'Brand Preference (Q2AX2)', 7),
(1981, 0, 1396270800, 1404136799, 'Med Soft SUV (S6)', 'LandRover Range Rover Evoque', 0, 0, 'Brand Preference (Q2AX2)', 4),
(1991, 0, 1404136800, 1412085599, 'Med Soft SUV (S6)', 'LandRover Range Rover Evoque', 0, 0, 'Brand Preference (Q2AX2)', 5),
(2001, 0, 1396270800, 1404136799, 'Med Soft SUV (S6)', 'Hyundai Santa Fe', 0, 0, 'Brand Preference (Q2AX2)', 5),
(2011, 0, 1404136800, 1412085599, 'Med Soft SUV (S6)', 'Hyundai Santa Fe', 0, 0, 'Brand Preference (Q2AX2)', 6),
(2021, 0, 1396270800, 1404136799, 'Med Soft SUV (S6)', 'Subaru Tribeca', 0, 0, 'Brand Preference (Q2AX2)', 1),
(2031, 0, 1404136800, 1412085599, 'Med Soft SUV (S6)', 'Subaru Tribeca', 0, 0, 'Brand Preference (Q2AX2)', 2),
(2041, 0, 1396270800, 1404136799, 'Med Soft SUV (S6)', 'Nissan Murano', 0, 0, 'Brand Preference (Q2AX2)', 0),
(2051, 0, 1404136800, 1412085599, 'Med Soft SUV (S6)', 'Nissan Murano', 0, 0, 'Brand Preference (Q2AX2)', 1),
(2061, 0, 1396270800, 1404136799, 'Med Soft SUV (S6)', 'Volkswagen Passat Alltrack', 0, 0, 'Brand Preference (Q2AX2)', 0),
(2071, 0, 1404136800, 1412085599, 'Med Soft SUV (S6)', 'Volkswagen Passat Alltrack', 0, 0, 'Brand Preference (Q2AX2)', 0),
(2081, 0, 1396270800, 1404136799, 'Med Soft SUV (S6)', 'Peugeot 4008', 0, 0, 'Brand Preference (Q2AX2)', 1),
(2091, 0, 1404136800, 1412085599, 'Med Soft SUV (S6)', 'Peugeot 4008', 0, 0, 'Brand Preference (Q2AX2)', 1),
(2101, 0, 1396270800, 1404136799, 'Med Soft SUV (S6)', 'Fiat Freemont', 0, 0, 'Brand Preference (Q2AX2)', 0),
(2111, 0, 1404136800, 1412085599, 'Med Soft SUV (S6)', 'Fiat Freemont', 0, 0, 'Brand Preference (Q2AX2)', 0),
(2121, 0, 1396270800, 1404136799, 'Med Rugged SUV (S7)', 'Jeep Grand Cherokee', 0, 0, 'Brand Preference (Q2AX2)', 8),
(2131, 0, 1404136800, 1412085599, 'Med Rugged SUV (S7)', 'Jeep Grand Cherokee', 0, 0, 'Brand Preference (Q2AX2)', 8),
(2141, 0, 1396270800, 1404136799, 'Med Rugged SUV (S7)', 'Toyota Prado', 0, 0, 'Brand Preference (Q2AX2)', 13),
(2151, 0, 1404136800, 1412085599, 'Med Rugged SUV (S7)', 'Toyota Prado', 0, 0, 'Brand Preference (Q2AX2)', 7),
(2161, 0, 1396270800, 1404136799, 'Med Rugged SUV (S7)', 'Jeep Cherokee', 0, 0, 'Brand Preference (Q2AX2)', 3),
(2171, 0, 1404136800, 1412085599, 'Med Rugged SUV (S7)', 'Jeep Cherokee', 0, 0, 'Brand Preference (Q2AX2)', 6),
(2181, 0, 1396270800, 1404136799, 'Med Rugged SUV (S7)', 'LandRover Discovery', 0, 0, 'Brand Preference (Q2AX2)', 2),
(2191, 0, 1404136800, 1412085599, 'Med Rugged SUV (S7)', 'LandRover Discovery', 0, 0, 'Brand Preference (Q2AX2)', 4),
(2201, 0, 1396270800, 1404136799, 'Med Rugged SUV (S7)', 'Mitsubishi Pajero', 0, 0, 'Brand Preference (Q2AX2)', 8),
(2211, 0, 1404136800, 1412085599, 'Med Rugged SUV (S7)', 'Mitsubishi Pajero', 0, 0, 'Brand Preference (Q2AX2)', 5),
(2221, 0, 1396270800, 1404136799, 'Med Rugged SUV (S7)', 'Nissan Pathfinder', 0, 0, 'Brand Preference (Q2AX2)', 3),
(2231, 0, 1404136800, 1412085599, 'Med Rugged SUV (S7)', 'Nissan Pathfinder', 0, 0, 'Brand Preference (Q2AX2)', 3),
(2241, 0, 1396270800, 1404136799, 'Med Rugged SUV (S7)', 'Kia Sorento', 0, 0, 'Brand Preference (Q2AX2)', 2),
(2251, 0, 1404136800, 1412085599, 'Med Rugged SUV (S7)', 'Kia Sorento', 0, 0, 'Brand Preference (Q2AX2)', 2),
(2261, 0, 1396270800, 1404136799, 'Med Rugged SUV (S7)', 'Isuzu MU-X', 0, 0, 'Brand Preference (Q2AX2)', 2),
(2271, 0, 1404136800, 1412085599, 'Med Rugged SUV (S7)', 'Isuzu MU-X', 0, 0, 'Brand Preference (Q2AX2)', 2),
(2281, 0, 1396270800, 1404136799, 'Med Rugged SUV (S7)', 'Holden Colorado 7', 0, 0, 'Brand Preference (Q2AX2)', 0),
(2291, 0, 1404136800, 1412085599, 'Med Rugged SUV (S7)', 'Holden Colorado 7', 0, 0, 'Brand Preference (Q2AX2)', 1),
(2301, 0, 1396270800, 1404136799, 'Med Rugged SUV (S7)', 'Toyota FJ Cruiser', 0, 0, 'Brand Preference (Q2AX2)', 2),
(2311, 0, 1404136800, 1412085599, 'Med Rugged SUV (S7)', 'Toyota FJ Cruiser', 0, 0, 'Brand Preference (Q2AX2)', 0),
(2321, 0, 1396270800, 1404136799, 'Med Rugged SUV (S7)', 'Mitsubishi Challenger', 0, 0, 'Brand Preference (Q2AX2)', 1),
(2331, 0, 1404136800, 1412085599, 'Med Rugged SUV (S7)', 'Mitsubishi Challenger', 0, 0, 'Brand Preference (Q2AX2)', 0),
(2341, 0, 1396270800, 1404136799, 'Large 4WD (S8)', 'Toyota LandCruiser', 0, 0, 'Brand Preference (Q2AX2)', 29),
(2351, 0, 1404136800, 1412085599, 'Large 4WD (S8)', 'Toyota LandCruiser', 0, 0, 'Brand Preference (Q2AX2)', 15),
(2361, 0, 1396270800, 1404136799, 'Large 4WD (S8)', 'LandRover Range Rover', 0, 0, 'Brand Preference (Q2AX2)', 4),
(2371, 0, 1404136800, 1412085599, 'Large 4WD (S8)', 'LandRover Range Rover', 0, 0, 'Brand Preference (Q2AX2)', 4),
(2381, 0, 1396270800, 1404136799, 'Large 4WD (S8)', 'Volkswagen Touareg', 0, 0, 'Brand Preference (Q2AX2)', 3),
(2391, 0, 1404136800, 1412085599, 'Large 4WD (S8)', 'Volkswagen Touareg', 0, 0, 'Brand Preference (Q2AX2)', 8),
(2401, 0, 1396270800, 1404136799, 'Large 4WD (S8)', 'Nissan Patrol', 0, 0, 'Brand Preference (Q2AX2)', 6),
(2411, 0, 1404136800, 1412085599, 'Large 4WD (S8)', 'Nissan Patrol', 0, 0, 'Brand Preference (Q2AX2)', 5),
(2421, 0, 1396270800, 1404136799, 'Workhorse (S9)', 'Toyota Hilux', 0, 0, 'Brand Preference (Q2AX2)', 11),
(2431, 0, 1404136800, 1412085599, 'Workhorse (S9)', 'Toyota Hilux', 0, 0, 'Brand Preference (Q2AX2)', 9),
(2441, 0, 1396270800, 1404136799, 'Workhorse (S9)', 'Holden Colorado', 0, 0, 'Brand Preference (Q2AX2)', 3),
(2451, 0, 1404136800, 1412085599, 'Workhorse (S9)', 'Holden Colorado', 0, 0, 'Brand Preference (Q2AX2)', 2),
(2461, 0, 1396270800, 1404136799, 'Workhorse (S9)', 'Holden Ute', 0, 0, 'Brand Preference (Q2AX2)', 5),
(2471, 0, 1404136800, 1412085599, 'Workhorse (S9)', 'Holden Ute', 0, 0, 'Brand Preference (Q2AX2)', 7),
(2481, 0, 1396270800, 1404136799, 'Workhorse (S9)', 'Nissan Navara', 0, 0, 'Brand Preference (Q2AX2)', 11),
(2491, 0, 1404136800, 1412085599, 'Workhorse (S9)', 'Nissan Navara', 0, 0, 'Brand Preference (Q2AX2)', 5),
(2501, 0, 1396270800, 1404136799, 'Workhorse (S9)', 'Ford Ranger', 0, 0, 'Brand Preference (Q2AX2)', 6),
(2511, 0, 1404136800, 1412085599, 'Workhorse (S9)', 'Ford Ranger', 0, 0, 'Brand Preference (Q2AX2)', 6),
(2521, 0, 1396270800, 1404136799, 'Workhorse (S9)', 'Volkswagen Amarok', 0, 0, 'Brand Preference (Q2AX2)', 3),
(2531, 0, 1404136800, 1412085599, 'Workhorse (S9)', 'Volkswagen Amarok', 0, 0, 'Brand Preference (Q2AX2)', 3),
(2541, 0, 1396270800, 1404136799, 'Workhorse (S9)', 'Isuzu D-Max', 0, 0, 'Brand Preference (Q2AX2)', 3),
(2551, 0, 1404136800, 1412085599, 'Workhorse (S9)', 'Isuzu D-Max', 0, 0, 'Brand Preference (Q2AX2)', 3),
(2561, 0, 1396270800, 1404136799, 'Workhorse (S9)', 'Mazda BT-50', 0, 0, 'Brand Preference (Q2AX2)', 4),
(2571, 0, 1404136800, 1412085599, 'Workhorse (S9)', 'Mazda BT-50', 0, 0, 'Brand Preference (Q2AX2)', 6),
(2581, 0, 1396270800, 1404136799, 'Workhorse (S9)', 'Mitsubishi Triton', 0, 0, 'Brand Preference (Q2AX2)', 3),
(2591, 0, 1404136800, 1412085599, 'Workhorse (S9)', 'Mitsubishi Triton', 0, 0, 'Brand Preference (Q2AX2)', 5),
(2601, 0, 1396270800, 1404136799, 'Workhorse (S9)', 'Ford Falcon Ute', 0, 0, 'Brand Preference (Q2AX2)', 5),
(2611, 0, 1404136800, 1412085599, 'Workhorse (S9)', 'Ford Falcon Ute', 0, 0, 'Brand Preference (Q2AX2)', 3),
(2621, 0, 1396270800, 1404136799, 'Workhorse (S9)', 'LandRover Defender', 0, 0, 'Brand Preference (Q2AX2)', 0),
(2631, 0, 1404136800, 1412085599, 'Workhorse (S9)', 'LandRover Defender', 0, 0, 'Brand Preference (Q2AX2)', 2),
(2641, 0, 1396270800, 1404136799, 'Workhorse (S9)', 'Nissan Patrol Cab Chassis', 0, 0, 'Brand Preference (Q2AX2)', 2),
(2651, 0, 1404136800, 1412085599, 'Workhorse (S9)', 'Nissan Patrol Cab Chassis', 0, 0, 'Brand Preference (Q2AX2)', 0),
(2661, 0, 1396270800, 1404136799, 'Workhorse (S9)', 'Great Wall V240', 0, 0, 'Brand Preference (Q2AX2)', 1),
(2671, 0, 1404136800, 1412085599, 'Workhorse (S9)', 'Great Wall V240', 0, 0, 'Brand Preference (Q2AX2)', 1),
(2681, 0, 1396270800, 1404136799, 'Workhorse (S9)', 'Great Wall V200', 0, 0, 'Brand Preference (Q2AX2)', 1),
(2691, 0, 1404136800, 1412085599, 'Workhorse (S9)', 'Great Wall V200', 0, 0, 'Brand Preference (Q2AX2)', 0),
(2701, 0, 1396270800, 1404136799, 'Peoplemover (S10)', 'Toyota Tarago', 0, 0, 'Brand Preference (Q2AX2)', 9),
(2711, 0, 1404136800, 1412085599, 'Peoplemover (S10)', 'Toyota Tarago', 0, 0, 'Brand Preference (Q2AX2)', 8),
(2721, 0, 1396270800, 1404136799, 'Peoplemover (S10)', 'Honda Odyssey', 0, 0, 'Brand Preference (Q2AX2)', 10),
(2731, 0, 1404136800, 1412085599, 'Peoplemover (S10)', 'Honda Odyssey', 0, 0, 'Brand Preference (Q2AX2)', 9),
(2741, 0, 1396270800, 1404136799, 'Peoplemover (S10)', 'Kia Carnival', 0, 0, 'Brand Preference (Q2AX2)', 8),
(2751, 0, 1404136800, 1412085599, 'Peoplemover (S10)', 'Kia Carnival', 0, 0, 'Brand Preference (Q2AX2)', 4),
(2761, 0, 1396270800, 1404136799, 'Peoplemover (S10)', 'Chrysler Voyager', 0, 0, 'Brand Preference (Q2AX2)', 1),
(2771, 0, 1404136800, 1412085599, 'Peoplemover (S10)', 'Chrysler Voyager', 0, 0, 'Brand Preference (Q2AX2)', 2),
(2781, 0, 1396270800, 1404136799, 'Peoplemover (S10)', 'Dodge Journey', 0, 0, 'Brand Preference (Q2AX2)', 4),
(2791, 0, 1404136800, 1412085599, 'Peoplemover (S10)', 'Dodge Journey', 0, 0, 'Brand Preference (Q2AX2)', 2),
(2801, 0, 1396270800, 1404136799, 'Peoplemover (S10)', 'Peugeot 5008', 0, 0, 'Brand Preference (Q2AX2)', 4),
(2811, 0, 1404136800, 1412085599, 'Peoplemover (S10)', 'Peugeot 5008', 0, 0, 'Brand Preference (Q2AX2)', 2),
(2821, 0, 1396270800, 1404136799, 'Peoplemover (S10)', 'Hyundai iMax', 0, 0, 'Brand Preference (Q2AX2)', 2),
(2831, 0, 1404136800, 1412085599, 'Peoplemover (S10)', 'Hyundai iMax', 0, 0, 'Brand Preference (Q2AX2)', 1),
(2841, 0, 1396270800, 1404136799, 'Peoplemover (S10)', 'Citroen C4 Picasso', 0, 0, 'Brand Preference (Q2AX2)', 1),
(2851, 0, 1404136800, 1412085599, 'Peoplemover (S10)', 'Citroen C4 Picasso', 0, 0, 'Brand Preference (Q2AX2)', 2),
(2861, 0, 1396270800, 1404136799, 'Peoplemover (S10)', 'Volkswagen Multivan', 0, 0, 'Brand Preference (Q2AX2)', 1),
(2871, 0, 1404136800, 1412085599, 'Peoplemover (S10)', 'Volkswagen Multivan', 0, 0, 'Brand Preference (Q2AX2)', 2),
(2881, 0, 1396270800, 1404136799, 'Peoplemover (S10)', 'Fiat Fiorino', 0, 0, 'Brand Preference (Q2AX2)', 1),
(2891, 0, 1404136800, 1412085599, 'Peoplemover (S10)', 'Fiat Fiorino', 0, 0, 'Brand Preference (Q2AX2)', 2),
(2901, 0, 1396270800, 1404136799, 'Peoplemover (S10)', 'Proton Exora', 0, 0, 'Brand Preference (Q2AX2)', 1),
(2911, 0, 1404136800, 1412085599, 'Peoplemover (S10)', 'Proton Exora', 0, 0, 'Brand Preference (Q2AX2)', 2),
(2921, 0, 1396270800, 1404136799, 'Peoplemover (S10)', 'Volkswagen Caddy', 0, 0, 'Brand Preference (Q2AX2)', 0),
(2931, 0, 1404136800, 1412085599, 'Peoplemover (S10)', 'Volkswagen Caddy', 0, 0, 'Brand Preference (Q2AX2)', 0),
(2941, 0, 1396270800, 1404136799, 'Peoplemover (S10)', 'Volkswagen Caravelle', 0, 0, 'Brand Preference (Q2AX2)', 1),
(2951, 0, 1404136800, 1412085599, 'Peoplemover (S10)', 'Volkswagen Caravelle', 0, 0, 'Brand Preference (Q2AX2)', 0),
(2961, 0, 1396270800, 1404136799, 'Peoplemover (S10)', 'Kia Rondo 7', 0, 0, 'Brand Preference (Q2AX2)', 0),
(2971, 0, 1404136800, 1412085599, 'Peoplemover (S10)', 'Kia Rondo 7', 0, 0, 'Brand Preference (Q2AX2)', 0),
(2981, 0, 1396270800, 1404136799, 'Peoplemover (S10)', 'SsangYong Stavic', 0, 0, 'Brand Preference (Q2AX2)', 0),
(2991, 0, 1404136800, 1412085599, 'Peoplemover (S10)', 'SsangYong Stavic', 0, 0, 'Brand Preference (Q2AX2)', 0),
(3001, 0, 1396270800, 1404136799, 'Sports (S13)', 'Volkswagen Golf GTI', 0, 0, 'Brand Preference (Q2AX2)', 10),
(3011, 0, 1404136800, 1412085599, 'Sports (S13)', 'Volkswagen Golf GTI', 0, 0, 'Brand Preference (Q2AX2)', 14),
(3021, 0, 1396270800, 1404136799, 'Sports (S13)', 'Subaru Impreza WRX', 0, 0, 'Brand Preference (Q2AX2)', 6),
(3031, 0, 1404136800, 1412085599, 'Sports (S13)', 'Subaru Impreza WRX', 0, 0, 'Brand Preference (Q2AX2)', 6),
(3041, 0, 1396270800, 1404136799, 'Sports (S13)', 'Nissan GTR', 0, 0, 'Brand Preference (Q2AX2)', 3),
(3051, 0, 1404136800, 1412085599, 'Sports (S13)', 'Nissan GTR', 0, 0, 'Brand Preference (Q2AX2)', 3),
(3061, 0, 1396270800, 1404136799, 'Sports (S13)', 'Mazda RX-7', 0, 0, 'Brand Preference (Q2AX2)', 1),
(3071, 0, 1404136800, 1412085599, 'Sports (S13)', 'Mazda RX-7', 0, 0, 'Brand Preference (Q2AX2)', 1),
(3081, 0, 1396270800, 1404136799, 'Sports (S13)', 'Mazda MX-5', 0, 0, 'Brand Preference (Q2AX2)', 1),
(3091, 0, 1404136800, 1412085599, 'Sports (S13)', 'Mazda MX-5', 0, 0, 'Brand Preference (Q2AX2)', 0),
(3101, 0, 1396270800, 1404136799, 'Sports (S13)', 'Toyota 86', 0, 0, 'Brand Preference (Q2AX2)', 4),
(3111, 0, 1404136800, 1412085599, 'Sports (S13)', 'Toyota 86', 0, 0, 'Brand Preference (Q2AX2)', 4),
(3121, 0, 1396270800, 1404136799, 'Sports (S13)', 'Ford Focus XR5', 0, 0, 'Brand Preference (Q2AX2)', 3),
(3131, 0, 1404136800, 1412085599, 'Sports (S13)', 'Ford Focus XR5', 0, 0, 'Brand Preference (Q2AX2)', 1),
(3141, 0, 1396270800, 1404136799, 'Sports (S13)', 'Mitsubishi Lancer Evolution', 0, 0, 'Brand Preference (Q2AX2)', 1),
(3151, 0, 1404136800, 1412085599, 'Sports (S13)', 'Mitsubishi Lancer Evolution', 0, 0, 'Brand Preference (Q2AX2)', 2),
(3161, 0, 1396270800, 1404136799, 'Sports (S13)', 'Mazda 3 MPS', 0, 0, 'Brand Preference (Q2AX2)', 2),
(3171, 0, 1404136800, 1412085599, 'Sports (S13)', 'Mazda 3 MPS', 0, 0, 'Brand Preference (Q2AX2)', 3),
(3181, 0, 1396270800, 1404136799, 'Sports (S13)', 'Subaru BRZ', 0, 0, 'Brand Preference (Q2AX2)', 1),
(3191, 0, 1404136800, 1412085599, 'Sports (S13)', 'Subaru BRZ', 0, 0, 'Brand Preference (Q2AX2)', 1),
(3201, 0, 1396270800, 1404136799, 'Sports (S13)', 'Hyundai Veloster', 0, 0, 'Brand Preference (Q2AX2)', 2),
(3211, 0, 1404136800, 1412085599, 'Sports (S13)', 'Hyundai Veloster', 0, 0, 'Brand Preference (Q2AX2)', 5),
(3221, 0, 1396270800, 1404136799, 'Sports (S13)', 'Volkswagen Scirocco', 0, 0, 'Brand Preference (Q2AX2)', 0),
(3231, 0, 1404136800, 1412085599, 'Sports (S13)', 'Volkswagen Scirocco', 0, 0, 'Brand Preference (Q2AX2)', 1),
(3241, 0, 1396270800, 1404136799, 'Sports (S13)', 'Renault Megane-Convertable', 0, 0, 'Brand Preference (Q2AX2)', 0),
(3251, 0, 1404136800, 1412085599, 'Sports (S13)', 'Renault Megane-Convertable', 0, 0, 'Brand Preference (Q2AX2)', 0),
(3261, 0, 1396270800, 1404136799, 'Sports (S13)', 'Hyundai Genesis Coupe', 0, 0, 'Brand Preference (Q2AX2)', 1),
(3271, 0, 1404136800, 1412085599, 'Sports (S13)', 'Hyundai Genesis Coupe', 0, 0, 'Brand Preference (Q2AX2)', 0),
(3281, 0, 1396270800, 1404136799, 'Sub-Light Passenger (S14)', 'Nissan Micra', 0, 0, 'Brand Preference (Q2AX2)', 8),
(3291, 0, 1404136800, 1412085599, 'Sub-Light Passenger (S14)', 'Nissan Micra', 0, 0, 'Brand Preference (Q2AX2)', 10),
(3301, 0, 1396270800, 1404136799, 'Sub-Light Passenger (S14)', 'Mitsubishi Mirage', 0, 0, 'Brand Preference (Q2AX2)', 2),
(3311, 0, 1404136800, 1412085599, 'Sub-Light Passenger (S14)', 'Mitsubishi Mirage', 0, 0, 'Brand Preference (Q2AX2)', 5),
(3321, 0, 1396270800, 1404136799, 'Sub-Light Passenger (S14)', 'Holden Barina Spark', 0, 0, 'Brand Preference (Q2AX2)', 8),
(3331, 0, 1404136800, 1412085599, 'Sub-Light Passenger (S14)', 'Holden Barina Spark', 0, 0, 'Brand Preference (Q2AX2)', 3),
(3341, 0, 1396270800, 1404136799, 'Sub-Light Passenger (S14)', 'Fiat 500', 0, 0, 'Brand Preference (Q2AX2)', 4),
(3351, 0, 1404136800, 1412085599, 'Sub-Light Passenger (S14)', 'Fiat 500', 0, 0, 'Brand Preference (Q2AX2)', 7),
(3361, 0, 1396270800, 1404136799, 'Sub-Light Passenger (S14)', 'Suzuki Alto', 0, 0, 'Brand Preference (Q2AX2)', 0),
(3371, 0, 1404136800, 1412085599, 'Sub-Light Passenger (S14)', 'Suzuki Alto', 0, 0, 'Brand Preference (Q2AX2)', 3),
(3381, 0, 1396270800, 1404136799, 'Sub-Light Passenger (S14)', 'Hyundai i10', 0, 0, 'Brand Preference (Q2AX2)', 0),
(3391, 0, 1404136800, 1412085599, 'Sub-Light Passenger (S14)', 'Hyundai i10', 0, 0, 'Brand Preference (Q2AX2)', 3),
(3401, 0, 1396270800, 1404136799, 'Sub-Light Passenger (S14)', 'Mazda 1', 0, 0, 'Brand Preference (Q2AX2)', 1),
(3411, 0, 1404136800, 1412085599, 'Sub-Light Passenger (S14)', 'Mazda 1', 0, 0, 'Brand Preference (Q2AX2)', 0),
(3421, 0, 1396270800, 1404136799, 'Sub-Light Passenger (S14)', 'Citroen C2', 0, 0, 'Brand Preference (Q2AX2)', 0),
(3431, 0, 1404136800, 1412085599, 'Sub-Light Passenger (S14)', 'Citroen C2', 0, 0, 'Brand Preference (Q2AX2)', 0),
(3441, 0, 1396270800, 1404136799, 'Sub-Light Passenger (S14)', 'Volkswagen Up!', 0, 0, 'Brand Preference (Q2AX2)', 2),
(3451, 0, 1404136800, 1412085599, 'Sub-Light Passenger (S14)', 'Volkswagen Up!', 0, 0, 'Brand Preference (Q2AX2)', 0),
(3461, 0, 1396270800, 1404136799, 'Sub-Light Passenger (S14)', 'Mitsubishi iMiev', 0, 0, 'Brand Preference (Q2AX2)', 3),
(3471, 0, 1404136800, 1412085599, 'Sub-Light Passenger (S14)', 'Mitsubishi iMiev', 0, 0, 'Brand Preference (Q2AX2)', 3),
(3481, 0, 1396270800, 1404136799, 'Sub-Light Passenger (S14)', 'Chery J1', 0, 0, 'Brand Preference (Q2AX2)', 3),
(3491, 0, 1404136800, 1412085599, 'Sub-Light Passenger (S14)', 'Chery J1', 0, 0, 'Brand Preference (Q2AX2)', 0),
(3501, 0, 1396270800, 1404136799, 'Sub-Compact SUV (S15)', 'Nissan Dualis', 0, 0, 'Brand Preference (Q2AX2)', 14),
(3511, 0, 1404136800, 1412085599, 'Sub-Compact SUV (S15)', 'Nissan Dualis', 0, 0, 'Brand Preference (Q2AX2)', 8),
(3521, 0, 1396270800, 1404136799, 'Sub-Compact SUV (S15)', 'Mitsubishi ASX', 0, 0, 'Brand Preference (Q2AX2)', 8),
(3531, 0, 1404136800, 1412085599, 'Sub-Compact SUV (S15)', 'Mitsubishi ASX', 0, 0, 'Brand Preference (Q2AX2)', 12),
(3541, 0, 1396270800, 1404136799, 'Sub-Compact SUV (S15)', 'Subaru XV', 0, 0, 'Brand Preference (Q2AX2)', 10),
(3551, 0, 1404136800, 1412085599, 'Sub-Compact SUV (S15)', 'Subaru XV', 0, 0, 'Brand Preference (Q2AX2)', 10),
(3561, 0, 1396270800, 1404136799, 'Sub-Compact SUV (S15)', 'Holden Trax', 0, 0, 'Brand Preference (Q2AX2)', 1),
(3571, 0, 1404136800, 1412085599, 'Sub-Compact SUV (S15)', 'Holden Trax', 0, 0, 'Brand Preference (Q2AX2)', 2),
(3581, 0, 1396270800, 1404136799, 'Sub-Compact SUV (S15)', 'Skoda Yeti', 0, 0, 'Brand Preference (Q2AX2)', 4),
(3591, 0, 1404136800, 1412085599, 'Sub-Compact SUV (S15)', 'Skoda Yeti', 0, 0, 'Brand Preference (Q2AX2)', 5),
(3601, 0, 1396270800, 1404136799, 'Sub-Compact SUV (S15)', 'Suzuki S-cross', 0, 0, 'Brand Preference (Q2AX2)', 0),
(3611, 0, 1404136800, 1412085599, 'Sub-Compact SUV (S15)', 'Suzuki S-cross', 0, 0, 'Brand Preference (Q2AX2)', 0),
(3621, 0, 1396270800, 1404136799, 'Sub-Compact SUV (S15)', 'Ford Ecosport', 0, 0, 'Brand Preference (Q2AX2)', 1),
(3631, 0, 1404136800, 1412085599, 'Sub-Compact SUV (S15)', 'Ford Ecosport', 0, 0, 'Brand Preference (Q2AX2)', 4),
(3641, 0, 1396270800, 1404136799, 'Sub-Compact SUV (S15)', 'SsangYong Korando', 0, 0, 'Brand Preference (Q2AX2)', 2),
(3651, 0, 1404136800, 1412085599, 'Sub-Compact SUV (S15)', 'SsangYong Korando', 0, 0, 'Brand Preference (Q2AX2)', 1),
(3661, 0, 1396270800, 1404136799, 'Sub-Compact SUV (S15)', 'Peugeot 2008', 0, 0, 'Brand Preference (Q2AX2)', 2),
(3671, 0, 1404136800, 1412085599, 'Sub-Compact SUV (S15)', 'Peugeot 2008', 0, 0, 'Brand Preference (Q2AX2)', 2),
(3681, 0, 1396270800, 1404136799, 'Sub-Compact SUV (S15)', 'Suzuki Jimny', 0, 0, 'Brand Preference (Q2AX2)', 2),
(3691, 0, 1404136800, 1412085599, 'Sub-Compact SUV (S15)', 'Suzuki Jimny', 0, 0, 'Brand Preference (Q2AX2)', 0),
(3701, 0, 1396270800, 1404136799, 'Sub-Compact SUV (S15)', 'Renault Captur', 0, 0, 'Brand Preference (Q2AX2)', 0),
(3711, 0, 1404136800, 1412085599, 'Sub-Compact SUV (S15)', 'Renault Captur', 0, 0, 'Brand Preference (Q2AX2)', 0);

-- --------------------------------------------------------

--
-- Table structure for table `library_file`
--

CREATE TABLE IF NOT EXISTS `library_file` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `year` int(4) NOT NULL,
  `source_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `server` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `date_uploaded` datetime NOT NULL,
  `tags` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2112 ;

--
-- Dumping data for table `library_file`
--

INSERT INTO `library_file` (`id`, `name`, `filename`, `year`, `source_id`, `author_id`, `server`, `location`, `type`, `date_uploaded`, `tags`) VALUES
(31, 'Link-test12', '54ac7d69adac2_Book1.csv', 2005, 371, 191, 'staging1.tips.potentiateglobal.com', '/var/www/tips_2/library/public/upload', 'application/vnd.ms-excel', '2015-01-08 09:45:12', '["tet","hfgh"]'),
(2001, 'testst123', '54b354ffd437d_big.docx', 2004, 371, 221, 'staging1.tips.potentiateglobal.com', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2015-01-12 16:59:17', '["column","vehicle","brand","unprompted","make","model","suv","med","consideration"]'),
(2011, 'testtesttest', '54b35b70c03fb_big1.docx', 2003, 371, 211, 'staging1.tips.potentiateglobal.com', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2015-01-14 09:35:58', '["General Public License","using","one","build","GNU"]'),
(2061, 'tytyrtytry', '54b35c1ada03a_big1.docx', 2005, 371, 211, 'staging1.tips.potentiateglobal.com', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2015-01-14 09:38:09', '["General Public License","using","one","build","GNU"]'),
(971, 'finaladd', '', 2001, 371, 211, 'staging1.tips.potentiateglobal.com', 'http://css-tricks.com/snippets/jquery/clear-a-file-input/', 'link', '2015-01-06 16:32:16', '["test"]'),
(1991, 'testtest', '54b361ffe47fd_big1.docx', 2010, 371, 211, 'staging1.tips.potentiateglobal.com', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2015-01-12 16:57:44', '["General Public License","using","one"]'),
(1171, 'beforefinetune', '', 2015, 371, 231, 'staging1.tips.potentiateglobal.com', 'http://php.net/', 'link', '2015-01-07 10:38:34', '["General Public License","using","one","build","GNU"]'),
(2111, 'testing brand over all', '54b5a663e7c63_big1.docx', 2006, 401, 0, 'staging1.tips.potentiateglobal.com', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2015-01-14 10:14:12', '["General Public License","using","one","build","GNU"]'),
(2081, 'test after js clean up', '54b4b99721049_big.docx', 2006, 371, 221, 'staging2.tips.potentiateglobal.com', '/var/www/tips_2/library/public/upload', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '2015-01-13 17:24:15', '["General Public License","using","one"]');

-- --------------------------------------------------------

--
-- Table structure for table `library_file_author`
--

CREATE TABLE IF NOT EXISTS `library_file_author` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=272 ;

--
-- Dumping data for table `library_file_author`
--

INSERT INTO `library_file_author` (`id`, `name`) VALUES
(1, 'James Pvt Ltd'),
(11, 'John Doe'),
(21, 'Chris Doe'),
(231, 'test123'),
(221, 'sanil'),
(151, 'auther'),
(211, 'test'),
(201, ''),
(191, 'John Doe123'),
(241, 'hello!!!&%^#'),
(251, 'facebook'),
(261, 't'),
(271, 'new');

-- --------------------------------------------------------

--
-- Table structure for table `library_file_categories`
--

CREATE TABLE IF NOT EXISTS `library_file_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `library_file_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_library_file_id` (`library_file_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1822 ;

--
-- Dumping data for table `library_file_categories`
--

INSERT INTO `library_file_categories` (`id`, `library_file_id`, `category_id`) VALUES
(81, 31, 361),
(71, 31, 321),
(1741, 2061, 361),
(1731, 2061, 321),
(1681, 2011, 361),
(1821, 2081, 341),
(1811, 2081, 361),
(1801, 2081, 321),
(1761, 1991, 361),
(1071, 1171, 351),
(1051, 1171, 331),
(1041, 1171, 361),
(1031, 1171, 321),
(1101, 31, 341),
(1671, 2011, 321),
(1661, 2001, 361),
(1751, 1991, 321),
(1721, 2011, 341),
(941, 971, 361),
(931, 971, 341),
(921, 971, 321),
(1061, 1171, 341),
(1651, 2001, 321),
(1231, 31, 331);

-- --------------------------------------------------------

--
-- Table structure for table `library_file_models`
--

CREATE TABLE IF NOT EXISTS `library_file_models` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `library_file_id` int(12) NOT NULL,
  `model_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_library_file_id` (`library_file_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2522 ;

--
-- Dumping data for table `library_file_models`
--

INSERT INTO `library_file_models` (`id`, `library_file_id`, `model_id`) VALUES
(141, 31, 281),
(131, 31, 31),
(2521, 2081, 161),
(2511, 2081, 141),
(1481, 31, 141),
(2361, 2011, 301),
(2351, 2011, 141),
(2341, 2011, 41),
(2301, 2011, 251),
(2291, 2011, 31),
(2501, 2081, 301),
(2491, 2081, 281),
(2481, 2081, 41),
(2471, 2081, 31),
(2421, 1991, 281),
(2411, 1991, 31),
(2401, 2061, 301),
(1291, 971, 281),
(1281, 971, 211),
(1271, 971, 141),
(1261, 971, 41),
(1251, 971, 31),
(1421, 1171, 121),
(2281, 2001, 281),
(1411, 1171, 301),
(1471, 31, 121),
(2391, 2061, 281),
(2381, 2061, 41),
(2371, 2061, 31),
(1401, 1171, 281),
(1391, 1171, 41),
(1381, 1171, 31),
(2271, 2001, 41),
(2261, 2001, 31),
(1441, 1171, 161),
(1431, 1171, 141);

-- --------------------------------------------------------

--
-- Table structure for table `link_keys`
--

CREATE TABLE IF NOT EXISTS `link_keys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `LINK_ID` bigint(20) NOT NULL DEFAULT '0',
  `FIELD_NAME` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `list_else`
--

CREATE TABLE IF NOT EXISTS `list_else` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `JOB_ID` varchar(30) NOT NULL DEFAULT '',
  `EMAIL` varchar(100) NOT NULL DEFAULT '',
  `NEW_EMAIL` varchar(100) NOT NULL DEFAULT '',
  `FIRST_NAME` varchar(100) DEFAULT NULL,
  `LAST_NAME` varchar(100) DEFAULT NULL,
  `BATCH_ID` varchar(12) DEFAULT 'BATCH_1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `NEW_EMAIL` (`NEW_EMAIL`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `list_later`
--

CREATE TABLE IF NOT EXISTS `list_later` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `JOB_ID` varchar(30) NOT NULL DEFAULT '',
  `EMAIL` varchar(100) NOT NULL DEFAULT '',
  `TIME_STAMP` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `EMAIL` (`EMAIL`),
  KEY `JOB_ID` (`JOB_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `list_remove`
--

CREATE TABLE IF NOT EXISTS `list_remove` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `JOB_ID` varchar(30) NOT NULL DEFAULT '',
  `EMAIL` varchar(100) NOT NULL DEFAULT '',
  `TIMESTAMP` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `JOB_ID` (`JOB_ID`),
  KEY `EMAIL` (`EMAIL`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `login_list`
--

CREATE TABLE IF NOT EXISTS `login_list` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `USERNAME` varchar(100) NOT NULL DEFAULT '',
  `JOB_ID` varchar(30) DEFAULT NULL,
  `PASSWORD` varchar(100) DEFAULT NULL,
  `EMAIL` varchar(100) NOT NULL DEFAULT '',
  `BATCH_ID` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_username` (`USERNAME`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `merged_qar`
--

CREATE TABLE IF NOT EXISTS `merged_qar` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `M_ID` varchar(6) DEFAULT NULL,
  `JOB_ID` varchar(6) DEFAULT NULL,
  `STATUS` tinyint(1) DEFAULT NULL,
  `SCOUNT` tinyint(3) NOT NULL,
  `NO_REDIRECT` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `M_ID` (`M_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ml_fields`
--

CREATE TABLE IF NOT EXISTS `ml_fields` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cloudrunner_sample_row_id` int(10) unsigned NOT NULL DEFAULT '0',
  `JOB_ID` varchar(20) NOT NULL DEFAULT '',
  `EMAIL` varchar(255) NOT NULL DEFAULT '',
  `FIELD_NAME` varchar(48) NOT NULL DEFAULT '',
  `FIELD_VALUE` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `JOB_ID` (`JOB_ID`),
  KEY `EMAIL` (`EMAIL`),
  KEY `FIELD_NAME` (`FIELD_NAME`),
  KEY `cloudrunner_sample_row_id` (`cloudrunner_sample_row_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=162 ;

--
-- Dumping data for table `ml_fields`
--

INSERT INTO `ml_fields` (`id`, `cloudrunner_sample_row_id`, `JOB_ID`, `EMAIL`, `FIELD_NAME`, `FIELD_VALUE`) VALUES
(1, 0, 'mda231', 'e52b69e90cda40e72e8ae84a9ae5756f', 'source', ''),
(11, 0, 'mda231', '9d6188a0f8ef34b38f3473aae7b2ce44', 'source', ''),
(21, 0, 'mda231', 'c5933619c3d0f63e50014ba1b8e049a9', 'source', ''),
(31, 0, 'mda231', '70701117153f7aa799140e8f66cfd722', 'source', ''),
(41, 0, 'mda231', '77728a1d85f798d067a77bd975ca347c', 'source', ''),
(51, 0, 'mda231', '43eb1397188a4d62709f275a1ff0a032', 'source', ''),
(61, 0, 'mda231', '61881eb0205158fc83543c675c6bce1e', '_route_', 'images/target_logo.png'),
(71, 0, 'mda231', '61881eb0205158fc83543c675c6bce1e', 'source', ''),
(81, 0, 'mda231', '79bab6e221843130e80fa01517878134', '_route_', 'sdfds'),
(91, 0, 'mda231', '79bab6e221843130e80fa01517878134', 'source', ''),
(101, 0, 'mda231', '12490b60168e3b7bac682eeea6d1d163', '_route_', 'sdfds'),
(111, 0, 'mda231', '12490b60168e3b7bac682eeea6d1d163', 'source', ''),
(121, 0, '', '198f73322779736d1b6b8114fd95930f', 'source', ''),
(131, 0, '', 'a1a8a4cf2d8a2af4abc971484b36f998', 'source', ''),
(141, 0, '', '29657d35304e62792e1bbc0d910dbd6c', 'source', ''),
(151, 0, '', '58500d197216cc62e0bfe7377eaf0acd', 'source', ''),
(161, 0, '', 'b057ba000d5848215547d11c950c982f', 'source', '');

-- --------------------------------------------------------

--
-- Table structure for table `ml_list_status`
--

CREATE TABLE IF NOT EXISTS `ml_list_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `JOB_ID` varchar(30) NOT NULL,
  `EMAIL` varchar(150) NOT NULL,
  `TIMESTAMP` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `STATUS` tinyint(2) NOT NULL COMMENT '1=link_clicked;2=terminated;3=quota_full',
  PRIMARY KEY (`id`),
  KEY `JOB_ID` (`JOB_ID`,`EMAIL`),
  FULLTEXT KEY `EMAIL` (`EMAIL`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `myshortcuts`
--

CREATE TABLE IF NOT EXISTS `myshortcuts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `description` varchar(128) NOT NULL,
  `url` varchar(64) NOT NULL,
  `create_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  `edit_date` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `myshortcuts`
--

INSERT INTO `myshortcuts` (`id`, `userid`, `description`, `url`, `create_date`, `edit_date`) VALUES
(1, 123, 'Test', 'http://staging1.tips.potentiateglobal.com/Report/#/index', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pre_coded_values`
--

CREATE TABLE IF NOT EXISTS `pre_coded_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `JOB_ID` varchar(20) NOT NULL DEFAULT '',
  `QKEY` varchar(20) NOT NULL DEFAULT '',
  `VALUE` varchar(50) NOT NULL DEFAULT '',
  `CODE` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `JOB_ID` (`JOB_ID`,`QKEY`,`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `qar_user`
--

CREATE TABLE IF NOT EXISTS `qar_user` (
  `USER_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `USER_NAME` varchar(20) NOT NULL DEFAULT '',
  `PASSWORD` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`USER_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `qmap`
--

CREATE TABLE IF NOT EXISTS `qmap` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `UKEY` varchar(30) NOT NULL DEFAULT '',
  `JOB_ID` varchar(30) NOT NULL,
  `QKEY` varchar(20) NOT NULL DEFAULT '',
  `QNUM` varchar(4) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_ukey` (`UKEY`),
  KEY `JOB_ID` (`JOB_ID`),
  KEY `QKEY` (`QKEY`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `quest`
--

CREATE TABLE IF NOT EXISTS `quest` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `JOB_ID` varchar(30) NOT NULL DEFAULT '',
  `QUEST_TEXT` text NOT NULL,
  `QUEST_TYPE` varchar(20) NOT NULL DEFAULT '',
  `QUEST_ID` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `JOB_ID` (`JOB_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `quest_attributes`
--

CREATE TABLE IF NOT EXISTS `quest_attributes` (
  `JOB_ID` varchar(30) NOT NULL DEFAULT '',
  `QUEST_ID` varchar(20) NOT NULL DEFAULT '',
  `FIELD_NAME` varchar(20) NOT NULL DEFAULT '',
  `FIELD_TEXT` varchar(255) NOT NULL DEFAULT '',
  `FIELD_VALUE` varchar(20) NOT NULL DEFAULT '',
  `RANK` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`RANK`),
  KEY `FIELD_NAME` (`FIELD_NAME`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `quest_values`
--

CREATE TABLE IF NOT EXISTS `quest_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `JOB_ID` varchar(30) NOT NULL DEFAULT '',
  `QUEST_ID` varchar(20) NOT NULL DEFAULT '',
  `ATTR_TEXT` varchar(255) NOT NULL DEFAULT '',
  `ATTR_VALUE` varchar(20) NOT NULL DEFAULT '',
  `RANK` bigint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `QUEST_ID` (`QUEST_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `quotas`
--

CREATE TABLE IF NOT EXISTS `quotas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `JOB_ID` varchar(30) NOT NULL DEFAULT '',
  `QUOTA_ID` varchar(50) NOT NULL DEFAULT '',
  `QUOTA_NAME` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `TOTAL` int(10) unsigned NOT NULL DEFAULT '0',
  `TYPE` tinyint(1) DEFAULT '1',
  `OP` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_quota_id` (`QUOTA_ID`),
  KEY `JOB_ID` (`JOB_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `quota_values`
--

CREATE TABLE IF NOT EXISTS `quota_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `QUOTA_ID` varchar(50) NOT NULL DEFAULT '',
  `FIELD_NAME` varchar(30) DEFAULT NULL,
  `FIELD_VALUE` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `QUOTA_ID` (`QUOTA_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `redirect`
--

CREATE TABLE IF NOT EXISTS `redirect` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `JOB_ID` varchar(30) NOT NULL DEFAULT '',
  `END_LINK` varchar(500) NOT NULL,
  `TERMINATE_LINK` varchar(255) DEFAULT NULL,
  `QUOTA_FULL_LINK` varchar(255) DEFAULT NULL,
  `CLOSED_LINK` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_job_id` (`JOB_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE IF NOT EXISTS `report` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `JOB_ID` varchar(30) NOT NULL DEFAULT '',
  `QUEST_ID` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `JOB_ID` (`JOB_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `rm_element`
--

CREATE TABLE IF NOT EXISTS `rm_element` (
  `ELEMENT_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `JOB_ID` varchar(50) DEFAULT NULL,
  `TYPE` varchar(20) NOT NULL DEFAULT '',
  `ELEMENT1` varchar(20) NOT NULL DEFAULT '',
  `ELEMENT2` varchar(20) NOT NULL DEFAULT '',
  `ELEMENT3` varchar(20) NOT NULL DEFAULT '',
  `FILTERS` varchar(250) NOT NULL DEFAULT '',
  `MVS` varchar(250) NOT NULL DEFAULT '',
  `DISPLAY` varchar(20) NOT NULL DEFAULT '',
  `RANGE` int(11) DEFAULT '0',
  `MEAN` int(11) DEFAULT '0',
  `MEDIAN` int(11) DEFAULT '0',
  `MODE` int(11) DEFAULT '0',
  `MODE_COUNT` int(11) DEFAULT '0',
  `OP` char(3) DEFAULT NULL,
  PRIMARY KEY (`ELEMENT_ID`),
  KEY `JOB_ID` (`JOB_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `rm_project`
--

CREATE TABLE IF NOT EXISTS `rm_project` (
  `PROJECT_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `NAME` varchar(30) NOT NULL DEFAULT '',
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`PROJECT_ID`),
  UNIQUE KEY `PROJECT_ID` (`PROJECT_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `rm_project_report`
--

CREATE TABLE IF NOT EXISTS `rm_project_report` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PROJECT_ID` bigint(20) NOT NULL DEFAULT '0',
  `REPORT_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `rm_report`
--

CREATE TABLE IF NOT EXISTS `rm_report` (
  `REPORT_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `NAME` varchar(30) NOT NULL DEFAULT '',
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`REPORT_ID`),
  UNIQUE KEY `REPORT_ID` (`REPORT_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `rm_report_elements`
--

CREATE TABLE IF NOT EXISTS `rm_report_elements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `REPORT_ID` bigint(20) NOT NULL DEFAULT '0',
  `ELEMENT_ID` bigint(20) NOT NULL DEFAULT '0',
  `POS` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `REPORT_ID` (`REPORT_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `rm_report_job`
--

CREATE TABLE IF NOT EXISTS `rm_report_job` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `REPORT_ID` bigint(20) NOT NULL DEFAULT '0',
  `JOB_ID` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `rm_report_user`
--

CREATE TABLE IF NOT EXISTS `rm_report_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `USERNAME` varchar(14) DEFAULT NULL,
  `REPORT_ID` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `rm_user`
--

CREATE TABLE IF NOT EXISTS `rm_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PROJECT_ID` bigint(20) NOT NULL DEFAULT '0',
  `USERNAME` varchar(30) NOT NULL DEFAULT '',
  `PASSWORD` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `REPORT_ID` (`PROJECT_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `surveys`
--

CREATE TABLE IF NOT EXISTS `surveys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SURVEY_ID` varchar(150) NOT NULL,
  `JOB_ID` varchar(30) NOT NULL DEFAULT '',
  `EMAIL` varchar(60) NOT NULL DEFAULT '',
  `TIME_TAKEN` int(10) DEFAULT NULL,
  `TIME_STAMP` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ATTEMPTS` int(2) DEFAULT NULL,
  `BATCH_ID` varchar(12) DEFAULT 'OPEN_LINK',
  `STATUS` tinyint(4) DEFAULT '0',
  `PROCESSED` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `SURVEY_ID` (`SURVEY_ID`),
  KEY `JOB_ID` (`JOB_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `temp_data`
--

CREATE TABLE IF NOT EXISTS `temp_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `JOB_ID` varchar(20) NOT NULL DEFAULT '',
  `EMAIL` varchar(50) NOT NULL DEFAULT '',
  `FIELD_NAME` varchar(20) NOT NULL DEFAULT '',
  `FIELD_VALUE` text NOT NULL,
  `PAGE` smallint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `JOB_ID` (`JOB_ID`,`EMAIL`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `terminated_data`
--

CREATE TABLE IF NOT EXISTS `terminated_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SURVEY_ID` varchar(80) DEFAULT NULL,
  `FIELD_NAME` varchar(30) DEFAULT NULL,
  `FIELD_VALUE` text,
  PRIMARY KEY (`id`),
  KEY `SURVEY_ID` (`SURVEY_ID`),
  KEY `FIELD_NAME` (`FIELD_NAME`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `terminated_surveys`
--

CREATE TABLE IF NOT EXISTS `terminated_surveys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SURVEY_ID` varchar(60) NOT NULL DEFAULT '',
  `JOB_ID` varchar(30) DEFAULT NULL,
  `EMAIL` varchar(60) DEFAULT NULL,
  `TIME_TAKEN` int(10) DEFAULT NULL,
  `TIME_STAMP` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ATTEMPTS` int(2) DEFAULT NULL,
  `BATCH_ID` varchar(12) DEFAULT NULL,
  `STATUS` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_survey_id` (`SURVEY_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `traffic`
--

CREATE TABLE IF NOT EXISTS `traffic` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CODE` tinyint(4) NOT NULL DEFAULT '0',
  `QTY` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `CODE` (`CODE`),
  UNIQUE KEY `unique_code` (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `unique_qkeys`
--

CREATE TABLE IF NOT EXISTS `unique_qkeys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `UKEY` varchar(50) NOT NULL DEFAULT '',
  `JOB_ID` varchar(10) NOT NULL DEFAULT '',
  `FIELD_NAME` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_ukey` (`UKEY`),
  KEY `UKEY` (`UKEY`),
  KEY `JOB_ID` (`JOB_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;
