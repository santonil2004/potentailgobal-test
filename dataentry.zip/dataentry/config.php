<?php

/**
 * configuration
 */
define('HOST_NAME', 'localhost');
define('DATABASE_NAME', 'potentiate_3');
define('DATABASE_USER', 'root');
define('DATABASE_PASSWORD', '');
