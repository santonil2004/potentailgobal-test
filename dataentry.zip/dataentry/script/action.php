<?php

/**
 * add segment
 * @global type $db
 */
function add_segment() {
    $data = $_REQUEST;

    global $db;

    if (isset($data['segment'])) {
        $data['segment'] = trim($data['segment'], '\"');
    }

    $name = getValue($data, 'segment', null);
    $segmentHayStack = get_segment(false);


    if (empty($name)) {
        setMessage('Invalid Segment!');
        return false;
    }


    if (!in_array($name, $segmentHayStack)) {
        $code = str_replace(' ', '_', strtolower($name));
        $admin_category_id = $db->create('admin_category', array(
                    'code' => $code,
                    'name' => $name,
                    'type' => 'Segment',
                    'description' => $name
                ))->id();

        if ($admin_category_id) {
            setMessage("Segment '$name : $admin_category_id' created successfully.", 'success');
        }
    } else {
        setMessage("Segment '$name' exist.");
    }
}

/**
 * Add brand
 * @global type $db
 */
function add_brand() {
    $data = $_REQUEST;
    global $db;


    if (isset($data['brand'])) {
        $data['brand'] = trim($data['brand'], '\"');
    }

    $name = getValue($data, 'brand', null);
    $parent_admin_category_id = getValue($data, 'segment_id', null);
    $brandHayStack = get_data_array('Brand', $parent_admin_category_id, false);


    if (empty($name) || empty($parent_admin_category_id)) {
        setMessage("Invalid Brand or Segment !");
    }

    if (!in_array($name, $brandHayStack)) {
        $code = str_replace(' ', '_', strtolower($name));
        $admin_category_id = $db->create('admin_category', array(
                    'code' => $code . '_' . $parent_admin_category_id,
                    'name' => $name,
                    'type' => 'Brand',
                    'description' => $name
                ))->id();

        if ($admin_category_id) {

            $db->create('admin_category_parent', array(
                'admin_category_id' => $admin_category_id,
                'parent_admin_category_id' => $parent_admin_category_id
            ))->id();

            setMessage("Brand '$name : $admin_category_id' created successfully.", 'success');
        }
    } else {
        setMessage("Brand '$name' exist.");
    }
}

/**
 * add model
 * @global type $db
 */
function add_model() {
    $data = $_REQUEST;

    global $db;

    if (isset($data['model'])) {
        $data['model'] = trim($data['model'], '\"');
    }

    $name = getValue($data, 'model', null);
    $parent_admin_category_id = getValue($data, 'brand_id', null);
    $segmentHayStack = get_data_array('Model', $parent_admin_category_id, false);

    if (empty($name) || empty($parent_admin_category_id)) {
        setMessage('Invalid Model or Brand!');
        return false;
    }


    if (!in_array($name, $segmentHayStack)) {
        $code = str_replace(' ', '_', strtolower($name));
        $admin_category_id = $db->create('admin_category', array(
                    'code' => $code . '_' . $parent_admin_category_id,
                    'name' => $name,
                    'type' => 'Model',
                    'description' => $name
                ))->id();

        if ($admin_category_id) {

            $db->create('admin_category_parent', array(
                'admin_category_id' => $admin_category_id,
                'parent_admin_category_id' => $parent_admin_category_id
            ))->id();

            setMessage("Segment '$name : $admin_category_id' created successfully.", 'success');
        }
    } else {
        setMessage("Model '$name' exist.");
    }
}

function get_admin_categories_by_parent() {

    $parent_admin_category_id = getValue($_REQUEST, 'parent_admin_category_id', null);
    $type = getValue($_REQUEST, 'type', 'Brand');
    $json = getValue($_REQUEST, 'json', 'true');

    if (empty($parent_admin_category_id)) {
        exit('Select Parent');
    }

    global $db;

    $sql = "SELECT
                ac.id,
                ac.name,
                acp.parent_admin_category_id 
            FROM 
                admin_category AS ac 
            JOIN 
                admin_category_parent AS acp 
            ON 
                ac.id = acp.admin_category_id 
            WHERE ac.type=:type
            AND acp.parent_admin_category_id = :id";

    $rows = $db->query($sql, array('type' => $type, 'id' => $parent_admin_category_id))->all();


    $html = '<option value="">-Select ' . $type . '-</option>';

    $names = array();

    foreach ($rows as $row) {
        $html.='<option value="' . $row->id . '">' . $row->name . '</option>';
        $names[] = $row->name;
    }

    if ($json == 'true') {
        echo json_encode($names);
        exit();
    }

    echo $html;
    exit;
}
