<?php

/**
 * isset check
 * @param array $array
 * @param type $key
 * @param type $default
 * @return array
 */
function getValue(array $array, $key, $default = '') {
    if (isset($array[$key])) {
        return @trim($array[$key]);
    }

    return $default;
}

/**
 * advance print r
 * @param type $data
 * @param type $label
 */
function r($data, $label = '') {
    $trace = debug_backtrace();
    $html = '';
    $html .= '<p style=background:red;padding:4px;margin:0px;>';
    $html .= 'File : <i>' . $trace[0]['file'] . ' </i>, at Line number :';
    $html .= '<b>' . $trace[0]['line'] . '</b>';
    $html .= '</p>';
    echo $html;

    if ($label) {
        echo $label . '<hr>';
    }

    echo '<pre style="background:#e0e0e0;padding:4px;margin:0px;clear:both;">';
    print_r($data);
    echo '</pre>';
}

function setMessage($msg, $type = 'error') {
    $_SESSION['flashMsg'] = array('msg' => $msg, 'class' => $type);
}

function getMessage() {
    if (isset($_SESSION['flashMsg'])) {
        $msg = $_SESSION['flashMsg']['msg'];
        $class = $_SESSION['flashMsg']['class'];
        unset($_SESSION['flashMsg']);
        return '<div class="msg ' . $class . '">' . $msg . '</div>';
    }
}

function fetch_admin_category($columns = '*', $type = null, $name = null) {
    global $db;

    $condtion = array();

    if (!empty($type)) {
        $condtion['type'] = $type;
    }


    if (!empty($name)) {
        $condtion['name'] = "%$name%";
    }

    return $db->select('admin_category', $columns, $condtion)->all();
}

function get_segment($json = true) {

    $rows = fetch_admin_category(array('id', 'name'), 'Segment');

    $segments = array();

    foreach ($rows as $row) {
        $segments[$row->id] = $row->name;
    }

    if ($json) {
        return json_encode(array_values($segments));
    }

    return $segments;
}

function get_data_array($type, $parent_admin_category_id = null, $json = true) {

    global $db;

    $condition = array();

    $sql = "SELECT
                ac.id,
                ac.name,
                ac.type,
                acp.parent_admin_category_id 
            FROM 
                admin_category AS ac 
            JOIN 
                admin_category_parent AS acp 
            ON 
                ac.id = acp.admin_category_id 
            WHERE ac.type=:type";

    $condition['type'] = $type;

    if (!empty($parent_admin_category_id)) {
        $sql.= " AND acp.parent_admin_category_id = :parent_admin_category_id";
        $condition['parent_admin_category_id'] = $parent_admin_category_id;
    }

    $rows = $db->query($sql, $condition)->all();

    $names = array();

    foreach ($rows as $row) {
        $names[$row->id] = $row->name;
    }

    if ($json) {
        return json_encode(array_values($names));
    }

    return $names;
}
