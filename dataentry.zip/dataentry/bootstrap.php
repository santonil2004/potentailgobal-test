<?php

session_start();

require_once 'config.php';
require_once 'script/db.php';
require_once 'script/functions.php';
require_once 'script/action.php';

/**
 * initalize db object
 */
Db::config('driver', 'mysql');
Db::config('host', HOST_NAME);
Db::config('database', DATABASE_NAME);
Db::config('user', DATABASE_USER);
Db::config('password', DATABASE_PASSWORD);

$db = Db::instance();


$action = trim(getValue($_REQUEST, 'action'), false);
/**
 * convert action to function call
 */
try {
    if ($action) {
        call_user_func($action);
    }
} catch (Exception $exc) {
    setMessage($exc->getMessage());
}


