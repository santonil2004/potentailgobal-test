$('document').ready(function() {

    $('#text-segment').textext({
        plugins: 'autocomplete suggestions',
        suggestions: segment
    }).bind('getSuggestions', function(e, data)
    {
        var $segment = segment,
                textext = $(e.target).textext()[0],
                query = (data ? data.query : '') || '';
        $(this).trigger(
                'setSuggestions',
                {result: textext.itemManager().filter($segment, query)}
        );
    });



    $('#text-brand').textext({
        plugins: 'autocomplete suggestions',
        suggestions: brand
    }).bind('getSuggestions', function(e, data)
    {
        var $brand = brand,
                textext = $(e.target).textext()[0],
                query = (data ? data.query : '') || '';
        $(this).trigger(
                'setSuggestions',
                {result: textext.itemManager().filter($brand, query)}
        );
    });



    $('#text-model').textext({
        plugins: 'autocomplete suggestions',
        suggestions: model
    }).bind('getSuggestions', function(e, data)
    {
        var $models = model,
                textext = $(e.target).textext()[0],
                query = (data ? data.query : '') || '';

        $(this).trigger(
                'setSuggestions',
                {result: textext.itemManager().filter($models, query)}
        );
    });


    /***************************************************************************
     * Change event
     **************************************************************************/

    $('.brand-entry #segment_id').change(function() {
        segment_id = $(this).val();
        $('.brand-entry .loading-brand').html('Fetching Brands...');
        $.ajax({
            type: "POST",
            url: "index.php?action=get_admin_categories_by_parent",
            data: {parent_admin_category_id: segment_id, type: 'Brand', json: 'true'}
        }).done(function(data) {
            brand = eval(data);
            $('.brand-entry .loading-brand').html('');
        });
    });


    $('.model-entry #segment_id').change(function() {
        segment_id = $(this).val();
        $('.model-entry .loading-msg').html('Fetching Brands...');

        $.ajax({
            type: "POST",
            url: "index.php?action=get_admin_categories_by_parent",
            data: {parent_admin_category_id: segment_id, type: 'Brand', json: 'false'}
        }).done(function(msg) {
            $('#brand_id').html(msg);
            $('.model-entry .loading-msg').html('');
        });
    });

    $('.model-entry #brand_id').change(function() {
        brand_id = $(this).val();
        $('.model-entry .loading-model').html('Fetching Models...');

        $.ajax({
            type: "POST",
            url: "index.php?action=get_admin_categories_by_parent",
            data: {parent_admin_category_id: brand_id, type: 'Model', json: 'true'}
        }).done(function(data) {
            model = eval(data);
            $('.model-entry .loading-model').html('');
        });

    });

});